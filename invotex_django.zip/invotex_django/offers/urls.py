from django.urls import path

from . import views

app_name = 'offers'

urlpatterns = [
    path('', views.offer_list, name='list'),
    path('offers/new/', views.offer_edit, name='new'),
    path('offers/next-number/', views.offer_next_number, name='next_number'),
    path('offers/<int:pk>/', views.offer_edit, name='edit'),
    path('offers/<int:pk>/download/', views.offer_download, name='download'),
    path('offers/<int:pk>/duplicate/', views.offer_duplicate, name='duplicate'),
    path('offers/<int:pk>/delete/', views.offer_delete, name='delete'),

    path('catalog/', views.machine_list, name='machine_list'),
    path('catalog/new/', views.machine_create, name='machine_new'),
    path('catalog/export/', views.catalog_export, name='catalog_export'),
    path('catalog/import/', views.catalog_import, name='catalog_import'),
    path('catalog/import-file/', views.catalog_import_file, name='catalog_import_file'),
    path('catalog/pdf/<slug:section>/', views.section_pdf, name='section_pdf'),
    path('catalog/<int:pk>/', views.machine_edit, name='machine_edit'),
    path('catalog/<int:pk>/pdf/', views.machine_pdf, name='machine_pdf'),
    path('catalog/<int:pk>/duplicate/', views.machine_duplicate, name='machine_duplicate'),
    path('catalog/<int:pk>/delete/', views.machine_delete, name='machine_delete'),

    path('titles/', views.titles_view, name='titles'),
    path('titles/<int:pk>/', views.title_edit, name='title_edit'),
    path('titles/<int:pk>/delete/', views.title_delete, name='title_delete'),

    path('settings/', views.settings_view, name='settings'),
    path('help/', views.help_view, name='help'),
]
