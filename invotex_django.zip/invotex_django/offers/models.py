# -*- coding: utf-8 -*-
import datetime
import os

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver

from .utils import build_title_choices, fmt_date, safe_filename, slugify_text, to_float, unique_slug


# The four sections of the machine catalog (tabs on the Machine catalog page).
SECTION_CHOICES = [
    ('aluminium', 'Aluminium machines'),
    ('steel', 'Steel machines'),
    ('wood', 'Wood working machines'),
    ('special', 'Special machines'),
]
SECTION_LABELS = dict(SECTION_CHOICES)
NEW_TITLE_VALUE = '__new__'          # the "+ Create new title" entry of the offer title dropdown


class Machine(models.Model):
    """A machine in the catalog (was one entry of catalog.json)."""
    section = models.CharField('Catalog section', max_length=20, choices=SECTION_CHOICES, default='steel', db_index=True)
    slug = models.SlugField(max_length=80, unique=True, editable=False,
                            help_text='Stable internal id; saved offers refer to it.')
    category = models.CharField('Category bar text (quotation)', max_length=250, blank=True)
    model_no = models.CharField('Model (quotation)', max_length=120, blank=True)
    title = models.CharField('Machine name (quotation title)', max_length=250)
    tech_title = models.CharField('Technical page title', max_length=300, blank=True)
    make = models.CharField('Make line, e.g. "Make: Dener, Turkey"', max_length=200, blank=True)
    origin = models.CharField('Country of origin', max_length=100, blank=True)
    image = models.ImageField('Picture', upload_to='machines/', blank=True)
    image_width = models.FloatField('Picture width on technical page (inches)', default=3.0,
                                    validators=[MinValueValidator(0.5), MaxValueValidator(7.0)])
    image_max_h = models.FloatField('Picture max height (inches)', default=2.3,
                                    validators=[MinValueValidator(0.5), MaxValueValidator(9.0)])
    lines = models.TextField('Quotation description lines (one per line)', blank=True)
    tech = models.TextField('Technical page content', blank=True)
    use_catalog_pages = models.BooleanField(
        'Add the technical specification exactly as uploaded (copy the catalogue pages as they are into the offer)',
        default=False)
    source_file = models.FileField('Original catalog file', upload_to='catalogs/', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['id']

    def __str__(self):
        return ('%s - %s' % (self.model_no, self.title)).strip(' -')

    @property
    def section_label(self):
        return SECTION_LABELS.get(self.section, self.section)

    def page_paths(self):
        """Absolute paths of the stored catalogue pages (in order)."""
        out = []
        for p in self.pages.all():
            try:
                if p.image and os.path.exists(p.image.path):
                    out.append(p.image.path)
            except Exception:
                continue
        return out

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify_text('%s-%s' % (self.model_no, self.title))[:60]
            self.slug = unique_slug(base, set(Machine.objects.values_list('slug', flat=True)))
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.image:
            self.image.delete(save=False)
        if self.source_file:
            self.source_file.delete(save=False)
        return super().delete(*args, **kwargs)

    def as_engine_dict(self):
        """The dict format the document engine (and the old catalog.json) uses."""
        path = ''
        if self.image:
            try:
                path = self.image.path
            except Exception:
                path = ''
        return {
            'id': self.slug, 'category': self.category, 'model': self.model_no, 'title': self.title,
            'tech_title': self.tech_title, 'lines': self.lines, 'make': self.make, 'origin': self.origin,
            'image': path, 'image_width': self.image_width, 'image_max_h': self.image_max_h, 'tech': self.tech,
            'section': self.section, 'use_catalog_pages': bool(self.use_catalog_pages),
            'catalog_pages': self.page_paths() if self.use_catalog_pages else [],
        }


class MachinePage(models.Model):
    """One page of an uploaded catalogue, stored as a picture so it can be placed in the offer exactly as it is."""
    machine = models.ForeignKey(Machine, related_name='pages', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='machine_pages/')
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return '%s - page %d' % (self.machine_id, self.order + 1)


@receiver(post_delete, sender=MachinePage)
def _remove_page_file(sender, instance, **kwargs):
    try:
        if instance.image:
            instance.image.delete(save=False)
    except Exception:
        pass


class SiteSettings(models.Model):
    """Single row with the defaults used for new offers (was settings.json)."""
    lead_time = models.CharField('Default lead time text', max_length=200, default='[to be confirmed]', blank=True)
    validity_days = models.PositiveIntegerField('Default validity (days)', default=7)
    delivery_area = models.CharField('Default delivery area', max_length=250, blank=True,
                                     default='Ras Al Khaimah, United Arab Emirates.')
    price_basis = models.CharField('Price basis line (under the table)', max_length=250, blank=True,
                                   default='EX WORKS PRICE WITHOUT SHIPPING COST')
    currency = models.CharField('Currency label', max_length=10, default='AED')
    offer_prefix = models.CharField('Offer number prefix', max_length=30, default='INVMCOFR', blank=True)
    default_title = models.CharField('Default offer title (cover)', max_length=120, default='STEEL WORKING MACHINES')
    replacements = models.JSONField('Extra text replacements [[find, replace], ...] (admin only)', default=list, blank=True)

    class Meta:
        verbose_name = 'settings'
        verbose_name_plural = 'settings'

    def __str__(self):
        return 'Invotex settings'

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def as_dict(self):
        return {
            'lead_time': self.lead_time, 'validity_days': self.validity_days, 'delivery_area': self.delivery_area,
            'price_basis': self.price_basis, 'currency': self.currency, 'offer_prefix': self.offer_prefix,
            'default_title': self.default_title, 'replacements': self.replacements or [],
        }


class OfferTitle(models.Model):
    """A choice in the Title dropdown of the offer form (cover page title)."""
    name = models.CharField('Title', max_length=120, unique=True)
    sort_order = models.PositiveIntegerField('Order', default=0, help_text='Smaller numbers appear first.')

    class Meta:
        ordering = ['sort_order', 'name']

    def __str__(self):
        return self.name

    @classmethod
    def choices(cls, default='', current=''):
        return build_title_choices(cls.objects.values_list('name', flat=True), default, current)


class OfferCounter(models.Model):
    """Last used sequence number per day (offer numbers look like PREFIX + yymmdd + -01)."""
    date_key = models.CharField(max_length=6, unique=True)
    last_no = models.PositiveIntegerField(default=0)

    def __str__(self):
        return '%s -> %d' % (self.date_key, self.last_no)


class Offer(models.Model):
    """A saved offer (was one JSON file per offer)."""
    company = models.CharField('Customer (company)', max_length=250)
    attention = models.CharField('Attention (contact person)', max_length=250, blank=True)
    location = models.CharField(max_length=250, blank=True)
    offer_no = models.CharField('Offer number', max_length=80, unique=True)
    date = models.DateField('Offer date')
    validity_days = models.PositiveIntegerField('Valid for (days)', default=7)
    title = models.CharField('Offer title', max_length=120, blank=True)
    delivery_area = models.CharField(max_length=250, blank=True)
    origin = models.CharField('Manufacturing origin (blank = automatic)', max_length=250, blank=True)
    discount_pct = models.DecimalField('Special discount %', max_digits=5, decimal_places=2, default=0, blank=True,
                                       validators=[MinValueValidator(0), MaxValueValidator(100)])
    # [{"id": machine slug, "qty": 1, "unit_price": "" or "12500.00", "lead_time": "..."}]
    lines = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at', '-id']

    def __str__(self):
        return '%s - %s' % (self.offer_no, self.company)

    def validity_date(self):
        return self.date + datetime.timedelta(days=int(self.validity_days or 0))

    def download_name(self):
        return '%s_%s.docx' % (safe_filename(self.offer_no), safe_filename(self.company).replace(' ', '_'))

    def to_engine_offer(self, settings_obj):
        """The dict the document engine expects (same shape as OfferState.to_offer in the desktop app)."""
        lines = []
        for ln in self.lines:
            lines.append({
                'id': ln['id'], 'qty': int(ln.get('qty') or 1),
                'unit_price': to_float(ln.get('unit_price')), 'lead_time': ln.get('lead_time', ''),
            })
        return {
            'company': self.company.strip(), 'attention': self.attention.strip(), 'location': self.location.strip(),
            'offer_no': self.offer_no.strip(), 'date': fmt_date(self.date), 'validity': fmt_date(self.validity_date()),
            'validity_days': int(self.validity_days or 0),
            'title': (self.title or settings_obj.default_title).strip(),
            'delivery_area': self.delivery_area.strip(), 'origin': self.origin.strip(),
            'discount_pct': float(self.discount_pct or 0), 'lines': lines,
            'price_basis': settings_obj.price_basis,
        }
