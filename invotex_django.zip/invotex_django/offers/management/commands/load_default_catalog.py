from django.core.management.base import BaseCommand

from offers.services import load_default_catalog, seed_default_titles


class Command(BaseCommand):
    help = 'Load the 10 machines (with pictures, sorted into the catalog sections) of the original program and the starting offer titles. Safe to repeat.'

    def handle(self, *args, **opts):
        n = load_default_catalog()
        t = seed_default_titles()
        self.stdout.write(self.style.SUCCESS('%d machine(s) and %d offer title(s) added.' % (n, t)))
