from django.core.management.base import BaseCommand

from offers import importer
from offers.models import SECTION_LABELS, Machine


class Command(BaseCommand):
    help = ('Sort existing machines into the catalog sections (Aluminium / Steel / Wood working / Special) by looking at their '
            'name and category. Use --dry-run to only show what would change.')

    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true', help='show the changes without saving them')

    def handle(self, *args, **opts):
        changed = 0
        for m in Machine.objects.all():
            guess = importer.guess_section('%s %s %s' % (m.title, m.category, m.model_no))
            if guess != m.section:
                changed += 1
                self.stdout.write('%-14s -> %-10s %s' % (SECTION_LABELS.get(m.section, m.section), guess, m))
                if not opts['dry_run']:
                    m.section = guess
                    m.save(update_fields=['section'])
        verb = 'would change' if opts['dry_run'] else 'changed'
        self.stdout.write(self.style.SUCCESS('%d machine(s) %s.' % (changed, verb)))
