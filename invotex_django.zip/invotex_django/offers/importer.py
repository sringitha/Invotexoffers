# -*- coding: utf-8 -*-
"""Catalog reader: turns a supplier catalog (PDF, Word, text or picture) into machine-catalog fields.

Pure python (no Django imports) so it can be tested on its own.
  * PDF   -> pdfplumber (text with positions) + pypdfium2 (page pictures)
  * Word  -> python-docx (paragraphs and tables)
  * text  -> plain text / csv / markdown
  * image -> used as the machine picture only (text recognition is not available)

The result of analyze() is a first draft: model, name, category, make, country, quotation description lines and
the technical page markup (see parse_markup in engine.py). The user reviews it in the machine form.
"""
import io
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter

from PIL import Image

IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.gif', '.tif', '.tiff'}
TEXT_EXT = {'.txt', '.md', '.csv'}
MAX_PAGES_AS_IS = 12            # catalogue pages copied "as they are" into the offer
PAGE_PICTURE_WIDTH = 1500       # pixels of a copied catalogue page


class ImportErrorMessage(Exception):
    """A problem with the uploaded file that can be shown to the user as it is."""


# ------------------------------------------------------------------ small helpers
def kind_of(filename):
    ext = os.path.splitext(filename or '')[1].lower()
    if ext == '.pdf':
        return 'pdf'
    if ext == '.docx':
        return 'docx'
    if ext == '.doc':
        return 'doc'
    if ext in IMAGE_EXT:
        return 'image'
    if ext in TEXT_EXT:
        return 'text'
    return ''


_DESPACE = re.compile(r'^(?:\S ){3,}\S$')


def _despace(c):
    return c.replace(' ', '') if _DESPACE.match(c) else c


# ------------------------------------------------------------------ PDF
def _words_to_rows(words):
    """pdfplumber words -> rows of cells [{'cells', 'size', 'y'}] (cells split on wide gaps)."""
    its = [w for w in words if (w.get('text') or '').strip()]
    its.sort(key=lambda w: (round(w['top'], 1), w['x0']))
    lines = []
    for w in its:
        size = float(w.get('size') or (w['bottom'] - w['top']) or 10)
        if lines and abs(lines[-1]['y'] - w['top']) <= max(lines[-1]['size'], size) * 0.5:
            lines[-1]['items'].append(w)
            lines[-1]['size'] = max(lines[-1]['size'], size)
        else:
            lines.append({'y': w['top'], 'size': size, 'items': [w]})
    rows = []
    for l in lines:
        l['items'].sort(key=lambda w: w['x0'])
        cells, cur, prev = [], '', None
        for w in l['items']:
            size = float(w.get('size') or 10)
            if prev is not None:
                gap = w['x0'] - prev['x1']
                sz = max(size, float(prev.get('size') or 10))
                if gap > sz * 1.5:
                    cells.append(cur.strip())
                    cur = w['text']
                    prev = w
                    continue
                cur += ' ' if gap > sz * 0.12 else ''
            cur += w['text']
            prev = w
        cells.append(cur.strip())
        cells = [_despace(c) for c in cells if c != '']
        if cells:
            rows.append({'cells': cells, 'size': l['size'], 'y': l['y']})
    return rows


def read_pdf(path, name=None):
    import pdfplumber
    pages = []
    try:
        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages, 1):
                try:
                    words = page.extract_words(x_tolerance=1.5, y_tolerance=2, keep_blank_chars=False,
                                               use_text_flow=False, extra_attrs=['size'])
                except Exception:
                    words = []
                pages.append({'num': i, 'rows': _words_to_rows(words), 'width': float(page.width), 'height': float(page.height)})
    except Exception as e:
        raise ImportErrorMessage('This PDF could not be read (%s).' % e)
    return {'kind': 'pdf', 'name': name or os.path.basename(path), 'pages': pages, 'path': path}


def pdf_pictures(path, page_nums, max_pictures=14):
    """Machine pictures found in the PDF: [{'image': PIL.Image, 'page': n}] largest first.

    Blank pictures and sizes that repeat on several pages (logos, banners) are skipped.
    """
    import pdfplumber
    cand, dims = [], Counter()
    with pdfplumber.open(path) as pdf:
        for pn in page_nums[:10]:
            try:
                page = pdf.pages[pn - 1]
                for im in page.images:
                    x0, x1 = max(0, im['x0']), min(float(page.width), im['x1'])
                    top, bottom = max(0, im['top']), min(float(page.height), im['bottom'])
                    if x1 - x0 < 60 or bottom - top < 40:
                        continue
                    pil = page.crop((x0, top, x1, bottom)).to_image(resolution=150).original.convert('RGB')
                    if pil.width < 200 or pil.height < 120 or _is_blank(pil):
                        continue
                    key = '%dx%d' % (round(x1 - x0), round(bottom - top))
                    dims[key] += 1
                    cand.append({'image': pil, 'page': pn, 'key': key, 'area': pil.width * pil.height})
                    if len(cand) >= 40:
                        break
            except Exception:
                continue
            if len(cand) >= 40:
                break
    keep = [c for c in cand if dims[c['key']] < 2] or cand
    keep.sort(key=lambda c: -c['area'])
    return keep[:max_pictures]


def _is_blank(pil):
    g = pil.convert('L').resize((24, 24))
    px = list(g.getdata())
    mean = sum(px) / len(px)
    sd = (sum((p - mean) ** 2 for p in px) / len(px)) ** 0.5
    return sd < 9


def render_pdf_pages(path, page_nums, width=PAGE_PICTURE_WIDTH):
    """The given pages (1-based numbers) as PIL images, exactly as printed."""
    import pypdfium2 as pdfium
    out = []
    pdf = pdfium.PdfDocument(path)
    try:
        for n in page_nums:
            page = pdf[n - 1]
            scale = width / float(page.get_width())
            out.append(page.render(scale=scale).to_pil().convert('RGB'))
    finally:
        try:
            pdf.close()
        except Exception:
            pass
    return out


# ------------------------------------------------------------------ Word
def read_docx(path, name=None):
    try:
        import docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError:
        raise ImportErrorMessage('Word files need the python-docx package (pip install python-docx).')
    try:
        d = docx.Document(path)
    except Exception as e:
        raise ImportErrorMessage('This Word file could not be read (%s).' % e)
    rows = []
    for el in d.element.body.iterchildren():
        tag = el.tag.rsplit('}', 1)[-1]
        if tag == 'p':
            p = Paragraph(el, d)
            t = (p.text or '').replace('\u00a0', ' ')
            if not t.strip():
                continue
            style = (p.style.name if p.style is not None else '') or ''
            cells = [c.strip() for c in re.split(r'\t+|\s{3,}', t) if c.strip()]
            rows.append({'cells': cells, 'size': 16.0 if re.match(r'(Heading|Title)', style, re.I) else 10.0, 'y': 0, 'docx': True})
        elif tag == 'tbl':
            tbl = Table(el, d)
            for r in tbl.rows:
                cells, seen = [], set()
                for c in r.cells:
                    if id(c._tc) in seen:      # merged cells repeat
                        continue
                    seen.add(id(c._tc))
                    cells.append(re.sub(r'\s+', ' ', c.text or '').strip())
                cells = [c for c in cells if c]
                if cells:
                    rows.append({'cells': cells, 'size': 10.0, 'y': 0, 'docx': True, 'table': True})
    return {'kind': 'docx', 'name': name or os.path.basename(path), 'pages': [{'num': 1, 'rows': rows}], 'path': path}


def docx_pictures(path, max_pictures=14):
    out = []
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if re.match(r'word/media/.+\.(png|jpe?g|gif|bmp|webp)$', n, re.I):
                    try:
                        im = Image.open(io.BytesIO(z.read(n))).convert('RGB')
                    except Exception:
                        continue
                    if im.width >= 160 and im.height >= 100 and not _is_blank(im):
                        out.append({'image': im, 'page': 1, 'area': im.width * im.height})
    except Exception:
        pass
    out.sort(key=lambda c: -c['area'])
    return out[:max_pictures]


def docx_to_pdf(path):
    """Word -> PDF with LibreOffice when it is installed. Returns a PDF path inside a new temp folder, or None."""
    exe = shutil.which('soffice') or shutil.which('libreoffice')
    if not exe:
        return None
    tmp = tempfile.mkdtemp(prefix='invotex_doc_')
    try:
        subprocess.run([exe, '--headless', '--convert-to', 'pdf', '--outdir', tmp, path],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180, check=False)
        pdf = os.path.join(tmp, os.path.splitext(os.path.basename(path))[0] + '.pdf')
        if os.path.exists(pdf):
            return pdf
    except Exception:
        pass
    shutil.rmtree(tmp, ignore_errors=True)
    return None


# ------------------------------------------------------------------ text / image
def read_text(path, name=None):
    with open(path, 'rb') as f:
        raw = f.read()
    for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            txt = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    rows = []
    for line in txt.splitlines():
        if not line.strip():
            continue
        if '|' in line or '\t' in line:
            cells = [c.strip() for c in re.split(r'\||\t', line) if c.strip()]
        else:
            cells = [c.strip() for c in re.split(r'\s{3,}', line) if c.strip()]
        rows.append({'cells': cells, 'size': 10.0, 'y': 0})
    return {'kind': 'text', 'name': name or os.path.basename(path), 'pages': [{'num': 1, 'rows': rows}], 'path': path}


def read_file(path, name=None):
    """Open an uploaded file. Returns the 'source' dict used by analyze()."""
    name = name or os.path.basename(path)
    k = kind_of(name)
    if k == 'pdf':
        return read_pdf(path, name)
    if k == 'docx':
        return read_docx(path, name)
    if k == 'text':
        return read_text(path, name)
    if k == 'image':
        try:
            Image.open(path).verify()
        except Exception:
            raise ImportErrorMessage('This picture could not be read.')
        return {'kind': 'image', 'name': name, 'pages': [], 'path': path}
    if k == 'doc':
        raise ImportErrorMessage('Old .doc files cannot be read. Please save the file as .docx or PDF and try again.')
    raise ImportErrorMessage('This file type is not supported. Use PDF, Word (.docx), text or a picture (jpg, png ...).')


def page_numbers(src, page_from=None, page_to=None):
    nums = [p['num'] for p in src['pages']]
    lo = page_from or 1
    hi = page_to or (max(nums) if nums else 1)
    return [n for n in nums if lo <= n <= hi]


def catalogue_page_images(src, page_from=None, page_to=None, limit=MAX_PAGES_AS_IS):
    """The 'as it is' pages of the catalogue as PIL images (max `limit`). Word files go through LibreOffice when present."""
    kind = src['kind']
    if kind == 'image':
        return [Image.open(src['path']).convert('RGB')]
    if kind == 'pdf':
        return render_pdf_pages(src['path'], page_numbers(src, page_from, page_to)[:limit])
    if kind == 'docx':
        pdf = docx_to_pdf(src['path'])
        if pdf:
            try:
                import pypdfium2 as pdfium
                n = len(pdfium.PdfDocument(pdf))
                return render_pdf_pages(pdf, list(range(1, n + 1))[:limit])
            finally:
                shutil.rmtree(os.path.dirname(pdf), ignore_errors=True)
        raise ImportErrorMessage('To copy a Word file exactly as it is, LibreOffice must be installed on the server. '
                                 'Save the file as PDF and upload the PDF instead.')
    raise ImportErrorMessage('Exact pages are only possible for PDF files, Word files and pictures.')


def candidate_pictures(src, page_from=None, page_to=None):
    kind = src['kind']
    if kind == 'image':
        return [{'image': Image.open(src['path']).convert('RGB'), 'page': 1, 'area': 1}]
    if kind == 'pdf':
        try:
            return pdf_pictures(src['path'], page_numbers(src, page_from, page_to))
        except Exception:
            return []
    if kind == 'docx':
        return docx_pictures(src['path'])
    return []


# ------------------------------------------------------------------ analysis (same rules as the browser version)
RX_CONTACT = re.compile(r"@|https?://|www\.|\b(tel|fax|phone|mobile|whatsapp|wechat|e-?mail|skype)\b[.: ]|\+\d{2,3}[\s-]?\d{2,}[\s\d-]{5,}|\b0\d{1,3}[-.\s]\d{3,4}[-.\s]\d{3,4}\b|\(\d{2,4}\)\s?\d{3,}", re.I)
RX_COMMERCIAL = re.compile(r"\b(price|prices|pricing|payment|t/t|l/c|validity|valid until|valid for|warranty|guarantee|delivery time|lead time|shipping|incoterms?|fob|exw|cif|hs code|quotation|quote|invoice|discount)\b|\b(usd|eur|aed|rmb|cny)\b|[$€£]\s?\d|\d\s?[$€£]", re.I)
RX_PAGENO = re.compile(r"^\s*(page|p\.)?\s*\d{1,3}(\s*(/|of)\s*\d{1,3})?\s*$", re.I)
RX_GENERIC = re.compile(r"^(product\s+)?(quotation|catalog(ue)?|brochure|offer|datasheet|data\s*sheet|machine\s+data|specifications?|technical\s+(data|specifications?|parameters?)|price\s+list|contents?|welcome|standard\s+specifications?|optional\s+specifications?)$", re.I)
RX_COMPANY = re.compile(r"\b(co\.?,?\s*ltd|ltd\.?|llc|gmbh|s\.?p\.?a\.?|s\.?r\.?l\.?|a\.?ş\.?|a\.s\b|inc\.?|corp(oration)?|machinery|makina|machines|industries|group|trading|factory|manufactur)", re.I)
RX_BULLET = re.compile(r"^[•●▪■◦·►»✓✔➢➤○□▫‣⁃*❑]\s*|^[-–—]\s+")
RX_NUMBERED = re.compile(r"^\d{1,2}[.)]\s+")
BULLET_ONLY = re.compile(r"^[•●▪■◦·►»✓✔➢➤○□▫‣⁃*❑]$")

CATS = [
    (r"v-?\s*groov|grooving", 'V GROOVING MACHINE'), (r"spot\s*weld", 'SPOT WELDING MACHINE'), (r"deburr", 'DEBURRING MACHINE'),
    (r"dust\s*(collector|filter)|wet\s*filter", 'DUST COLLECTOR'), (r"corner\s*notch", 'CORNER NOTCHER'),
    (r"(pipe|tube).{0,60}notch|notch.{0,60}(pipe|tube)", 'PIPE NOTCHING MACHINE'), (r"notch", 'NOTCHING MACHINE'),
    (r"plate\s*(bending|rolling)|roll(ing)?\s*machine|section\s*roller", 'PLATE / SECTION ROLLING MACHINE'),
    (r"press\s*brake|bending machine", 'CNC HYDRAULIC PRESS BRAKE'), (r"shear(ing)?\b", 'HYDRAULIC SHEARING MACHINE'),
    (r"fib(er|re)\s*laser.*(weld)|laser\s*weld", 'HANDHELD FIBER LASER WELDING MACHINE'), (r"fib(er|re)\s*laser|laser\s*cut", 'FIBER LASER CUTTING MACHINE'),
    (r"band\s*saw", 'BAND SAW'), (r"pipe|tube\s*notch|notching", 'PIPE NOTCHING MACHINE'), (r"compressor", 'SCREW AIR COMPRESSOR'),
    (r"lathe", 'LATHE MACHINE'), (r"milling", 'MILLING MACHINE'), (r"drill(ing)?\s*machine|drilling", 'DRILLING MACHINE'),
    (r"panel\s*saw|sliding\s*table|beam\s*saw", 'PANEL SAW'), (r"edge\s*band", 'EDGE BANDING MACHINE'), (r"edge\s*sand|sanding", 'EDGE SANDING MACHINE'),
    (r"cnc\s*router|router", 'CNC ROUTER'), (r"boring", 'CNC BORING MACHINE'), (r"mitre|miter|cutting\s*saw|double.?head", 'ALUMINIUM CUTTING SAW'),
    (r"press\b", 'POWER PRESS'), (r"plasma", 'CNC PLASMA CUTTING MACHINE'), (r"grinder|grinding", 'GRINDING MACHINE'), (r"welding", 'WELDING MACHINE'),
]
CATS = [(re.compile(rx, re.I), name) for rx, name in CATS]
COUNTRIES = [
    (r"\b(china|jinan|shandong|guangzhou|shenzhen|shanghai|jiangsu|zhejiang|foshan|wuhan|hangzhou|beijing|prc)\b", 'China'),
    (r"(turkey|türkiye|turkiye|istanbul|bursa|izmir|ankara|konya|\ba\.?ş\b|san\.?\s*ve\s*t[iİı]c|t[iİı]caret)", 'Turkey'),
    (r"\b(italy|italia|s\.?p\.?a\.?|s\.?r\.?l\.?|milano|bologna|veneto|brescia)\b", 'Italy'), (r"\b(germany|deutschland|gmbh)\b", 'Germany'),
    (r"\b(taiwan|taichung|taipei)\b", 'Taiwan'), (r"\b(spain|espa[nñ]a)\b", 'Spain'), (r"\b(india|gujarat|pune)\b", 'India'),
    (r"\b(czech|brno)\b", 'Czech Republic'), (r"\b(korea|seoul)\b", 'Korea'), (r"\b(japan|tokyo|osaka)\b", 'Japan'),
    (r"\b(poland|polska)\b", 'Poland'), (r"\b(portugal)\b", 'Portugal'), (r"\b(france|francais)\b", 'France'),
]
COUNTRIES = [(re.compile(rx, re.I), name) for rx, name in COUNTRIES]
KEYSPEC = re.compile(r"capacity|power|motor|length|width|diameter|thickness|working|area|stroke|speed|dimension|size|weight|pressure|flow|force|tonnage|cutting|bending|travel|range|voltage|rpm", re.I)
MODEL_RX = re.compile(r"\b(?:[A-Z]{1,4}-[A-Z] ?\d{2,5}|[A-Z]{2,6}[- ]?\d{2,5}|[A-Z]-?\d{2,5})[A-Z0-9]*(?:[/-][A-Z0-9]+)*\b")
MODEL_NOSPACE = re.compile(r"\b(?:[A-Z]{1,4}-[A-Z]\d{2,5}|[A-Z]{2,6}[-_]?\d{2,5}|[A-Z][-_]?\d{2,5})[A-Z0-9]*(?:[/-][A-Z0-9]+)*\b")
MODEL_BAD = re.compile(r"^(ISO|IP|MT|CE|EN|DIN|USB|AC|DC|HP|TUV|SGS|FDA|CNC|PLC|LED|LCD|RPM|KW|PDF|TEL|FAX|NO|MM|CM|KG|HZ|BAR|MPA|KN|PCS|SET|NM|DB|RAL|ASA|AISI|SAE|ST|ESA|MAX|MIN|OPT|PAGE|FIG|OF|ON|IN|AT|BY|TO|UP|AS|OR|IS|DN)[-\s]?\d", re.I)
SEC_WORDS = re.compile(r"\b(range|characteristics|specifications?|dimensions?|features?|description|advantages|optional|standard|parameters?|configuration|accessories|performance|technical|contents|introduction|applications?|details?|equipment|environment|software|weight|capacity|quotation|catalog(ue)?|brochure|terms|conditions|information|sales|delivery|payment|warranty|guarantee|origin|offer|general|options?)\b", re.I)
LEGAL = re.compile(r"(co\.?,?\s*ltd|\bltd\b|\bllc\b|\bgmbh\b|\bs\.?p\.?a\b|\bs\.?r\.?l\b|\ba\.?[sş]\b|\binc\b|\bcorp)", re.I)
COMPANY_STRIP = re.compile(r"(co\.?,?\s*ltd\.?|\bltd\.?|\bllc|\bgmbh|\bs\.?p\.?a\.?|\binc\.?|\bcorp\.?|\ba\.?[sş]\.?(?=\s|$)|\bsan\.?\s*ve\s*t[iİı]caret|\bsanayi|\bt[iİı]caret|\bmakina|\bmakine|\bmachinery|\bmachines?|\bgroup|\btrading|\bindustr(y|ies)|\bequipment|\bcompany|\btools?\b|\bco\.)", re.I)
TYPO = {'Lenght': 'Length', 'lenght': 'length', 'Heigth': 'Height', 'Widht': 'Width', 'Capacty': 'Capacity', 'Dimention': 'Dimension', 'Dimentions': 'Dimensions'}
RX_TYPO = re.compile(r"\b(Lenght|lenght|Heigth|Widht|Capacty|Dimention|Dimentions)\b")
DIMRX = re.compile(r"\b(area|length|width|thickness|working\s*(size|range|table|stroke)|table\s*(size|length|width)|plate\s*size|sheet\s*size|processing\s*(range|size))\b", re.I)
NODIM = re.compile(r"overall|dimension|packing|weight|voltage|power|motor|accura|precision|resolution|repeat|speed|cable|noise|air\s*(flow|pressure)|oil|tank|clearance|margin|travel|throat|gap|rate|ratio|diameter of|pipe|hose|tolerance", re.I)
GENERIC_NAME_WORDS = re.compile(r"\b(catalog(ue)?|brochure|data\s*sheet|datasheet|data|sheet|en|eng|english|pdf|new|final|copy|quotation|offer)\b", re.I)


def _norm(s):
    return re.sub(r'\s+', ' ', re.sub(r'\d+', '#', s.lower())).strip()


def _cap1(s):
    return re.sub(r'\s+', ' ', s).strip()


def _fixt(t):
    return RX_TYPO.sub(lambda m: TYPO[m.group(0)], t)


def _clean(s):
    return re.sub(r'\s+', ' ', s.replace('|', '/')).strip()


def analyze(src, page_from=None, page_to=None, no_commercial=True, no_contact=True, no_repeats=True):
    """Draft catalog fields from a source made by read_file()."""
    lo, hi = page_from or 1, page_to or 10 ** 6
    pages = [p for p in src['pages'] if lo <= p['num'] <= hi]
    removed = []
    repeat = set()
    if no_repeats and len(pages) >= 3:
        cnt = Counter()
        for p in pages:
            seen = set()
            for r in p['rows']:
                k = _norm(' '.join(r['cells']))
                if len(k) > 3 and k not in seen:
                    seen.add(k)
                    cnt[k] += 1
        need = max(3, -(-len(pages) * 4 // 10))
        repeat = {k for k, n in cnt.items() if n >= need}
    sizes = []
    for p in pages:
        for r in p['rows']:
            ln = len(' '.join(r['cells']))
            sizes += [r['size']] * len(range(0, min(ln, 40), 4))
    sizes.sort()
    body = sizes[len(sizes) // 2] if sizes else 10.0

    rows = []
    for p in pages:
        for r in p['rows']:
            text = ' '.join(r['cells'])
            why = ''
            if RX_PAGENO.match(text):
                continue
            if _norm(text) in repeat:
                why = 'repeated header/footer'
            elif no_contact and RX_CONTACT.search(text):
                why = 'contact details'
            elif no_commercial and RX_COMMERCIAL.search(text):
                why = 'price / payment / warranty'
            if why:
                removed.append({'text': text, 'why': why})
                continue
            rr = dict(r)
            rr['page'] = p['num']
            rows.append(rr)
    all_text = '\n'.join(' '.join(r['cells']) for r in rows)

    # ---- title / model
    named = None
    for r in [{'cells': [x['text']]} for x in removed] + rows:
        mm = re.match(r'^(?:model|machine|product)\s*[:\-]\s*(.{8,100})$', ' '.join(r['cells']).strip(), re.I)
        if mm and not RX_COMMERCIAL.search(mm.group(1)):
            named = _cap1(mm.group(1))
            break
    base = re.sub(r'[_.]+', ' ', re.sub(r'\.[a-z0-9]+$', '', src.get('name') or '', flags=re.I))
    cat_guess, cat_rx = '', None
    for rx, name in CATS:
        if rx.search(all_text[:3000] + ' ' + base.replace('-', ' ')):
            cat_guess, cat_rx = name, rx
            break

    def has_model(t):
        return any(not MODEL_BAD.match(m.group(0)) for m in MODEL_NOSPACE.finditer(t.upper()))

    cand = []
    for r in rows[:120]:
        t = ' '.join(r['cells'])
        if not (4 <= len(t) <= 90) or t.rstrip().endswith(':') or RX_GENERIC.match(t.strip()) or SEC_WORDS.search(t) or RX_COMPANY.search(t) \
                or re.match(r'^\d+$', t) or r.get('table') or RX_BULLET.match(t) or len(r['cells']) > 2 or re.search(r'\S\s*:\s*\S', t):
            continue
        if len(re.sub(r'[^A-Za-z]', '', t)) / float(len(t)) < 0.55:
            continue
        sc = r['size'] + (4 if cat_rx and cat_rx.search(t) else 0) + (4 if has_model(t) else 0)
        cand.append((sc, r['page'], r))
    cand.sort(key=lambda x: (-x[0], x[1]))
    title = named or (_cap1(' '.join(cand[0][2]['cells'])) if cand else '')

    score = Counter()

    def scan(txt, w):
        for m in MODEL_RX.finditer(txt):
            s = m.group(0).strip()
            if MODEL_BAD.match(s) or len(s) < 3:
                continue
            score[s] += w

    scan(title.upper(), 6)
    for tk in re.split(r'[ _]+', re.sub(r'\.[A-Z0-9]+$', '', (src.get('name') or '').upper())):
        for m in MODEL_NOSPACE.finditer(tk):
            s = m.group(0)
            if not MODEL_BAD.match(s):
                score[s.replace('_', '-')] += 5
    for r in rows[:40]:
        for m in MODEL_NOSPACE.finditer(' '.join(r['cells']).upper()):
            if not MODEL_BAD.match(m.group(0)):
                score[m.group(0)] += 2
    scan(all_text.upper(), 0.3)
    lbl = re.search(r"\b[Mm]odel(?:\s*(?:[Nn]o\.?|[Nn]umber|[Nn]ame))?\s*[:\-]\s*([A-Z0-9][A-Z0-9\-/.]{2,24}(?: [A-Z0-9\-/]{2,12})?)", all_text)
    if lbl:
        m = lbl.group(1).strip()
        if re.search(r'\d', m) and not MODEL_BAD.match(m):
            score[m] += 8
    model = score.most_common(1)[0][0] if score else ''
    if not title or (cat_guess and model and not has_model(title) and not (cat_rx and cat_rx.search(title))):
        nm = re.sub(r'\s+', ' ', GENERIC_NAME_WORDS.sub(' ', base)).strip()
        if cat_guess and model:
            title = ('%s %s' % (cat_guess, model)).upper()
        elif not title and nm:
            title = nm.upper()

    # ---- category / make / origin
    category = ''
    for rx, name in CATS:
        if rx.search(title):
            category = name
            break
    category = category or cat_guess
    make = origin = ''
    comp_row = None
    for t in [r['text'] for r in removed] + [' '.join(r['cells']) for r in rows]:
        if len(t) >= 80 or re.search(r'machine\s+(data|quotation)', t, re.I):
            continue
        if re.match(r'^(to|attn|attention|customer|buyer|bill\s*to|ship\s*to)\b\s*[:.]', t, re.I) or re.search(r'\b(no|date|ref)\s*[:.]\s*\w', t, re.I):
            continue
        if LEGAL.search(t) or (re.search(r'(makina|machinery|machines)', t, re.I) and len(t.split()) <= 4 and t == t.upper()):
            comp_row = t
            break
    ctx = (comp_row or '') + ' ' + ' '.join(r['text'] for r in removed) + ' ' + all_text[:2500]
    for rx, c in COUNTRIES:
        if rx.search(ctx):
            origin = c
            break
    if comp_row:
        b = COMPANY_STRIP.sub(' ', comp_row)
        b = re.sub(r'\s+', ' ', re.sub(r'[.,]+', ' ', b))
        b = re.sub(r'^(jinan|guangzhou|shandong)\s+', '', b, flags=re.I).strip()
        if 1 < len(b) < 40:
            make = 'Make: ' + b + (', ' + origin if origin else '')

    # ---- markup
    items = []
    state = {'last': None}

    def push(t, **kw):
        it = dict(kw, t=t)
        items.append(it)
        state['last'] = it if t in ('para', 'bullet') else None

    prev = None
    for r in rows:
        cells = list(r['cells'])
        if len(cells) >= 2 and re.match(r'^[:：]', cells[1]):
            cells = [cells[0], re.sub(r'^[:：]\s*', '', ' '.join(cells[1:]))]
        if len(cells) >= 2 and not BULLET_ONLY.match(cells[0]):
            cells[0] = re.sub(r'^[❑□▪■●•◦·]+\s*', '', cells[0])
        text = ' '.join(cells)
        if title and _cap1(text) == title:
            prev = r
            continue
        if len(cells) > 1 and (BULLET_ONLY.match(cells[0]) or re.match(r'^\d{1,2}[.)]$', cells[0])):
            push('bullet', text=' '.join(cells[1:]))
            prev = r
            continue
        if len(cells) == 1 and (RX_BULLET.match(text) or RX_NUMBERED.match(text)):
            push('bullet', text=RX_NUMBERED.sub('', RX_BULLET.sub('', text, count=1), count=1))
            prev = r
            continue
        if len(cells) >= 2 and all(6 <= len(c) <= 60 and c == c.upper() and re.search(r'[A-Z]{3}', c) and not re.search(r'\d', c) for c in cells):
            for c in cells:
                push('bar', text=c)
            prev = r
            continue
        if len(cells) >= 4 and len(cells) % 2 == 0 and all(
                (re.search(r'[A-Za-z]{3}', c) and not re.match(r'^\d', c) and len(c) <= 50) if i % 2 == 0 else re.search(r'\d', c)
                for i, c in enumerate(cells)):
            for i in range(0, len(cells), 2):
                push('spec', cells=[re.sub(r':\s*$', '', cells[i]), cells[i + 1]])
            prev = r
            continue
        if len(cells) == 1:
            t = text.strip()
            m = re.match(r'^([A-Za-z][^:|]{1,45}):\s*(\S.*)$', t)
            is_head = (r['size'] >= body * 1.18 and len(t) <= 70 and not re.search(r'[.;,]$', t)) or \
                      (4 <= len(t) <= 60 and t == t.upper() and re.search(r'[A-Z]{4}', t) and not re.search(r'\d{3,}', t) and not re.search(r'[.;]$', t))
            if is_head and not RX_GENERIC.match(t):
                push('bar', text=t.upper())
                prev = r
                continue
            if RX_GENERIC.match(t):
                prev = r
                continue
            if m and len(m.group(1).split()) <= 6:
                push('spec', cells=[m.group(1).strip(), m.group(2).strip()])
                prev = r
                continue
            near = bool(prev) and (False if r.get('docx') else (r['page'] == prev['page'] and abs(prev['y'] - r['y']) <= r['size'] * 1.9))
            last = state['last']
            if last and near and (re.match(r'^[a-z(]', t) or not re.search(r'[.:;!?]$', last['text'])):
                last['text'] += ' ' + t
                prev = r
                continue
            push('para', text=t)
            prev = r
            continue
        if len(cells) == 2:
            if len(cells[0]) <= 60:
                push('spec', cells=[re.sub(r':\s*$', '', cells[0]), cells[1]])
            else:
                push('para', text=text)
            prev = r
            continue
        push('row', cells=cells)
        prev = r

    out, overview, has_bar, in_table, ov = [], [], False, None, 0

    def gap():
        if out and out[-1] != '':
            out.append('')

    for it in items:
        t = it['t']
        if t == 'bar':
            gap()
            out.append('## ' + _clean(it['text']))
            has_bar, in_table = True, None
        elif t == 'para':
            if not has_bar and ov < 2 and len(' '.join(overview)) < 520:
                overview.append(_clean(it['text']))
                ov += 1
            else:
                if not has_bar:
                    gap()
                    out.append('## DESCRIPTION')
                    has_bar = True
                out.append(_clean(it['text']))
            in_table = None
        elif t == 'bullet':
            if not has_bar:
                gap()
                out.append('## FEATURES')
                has_bar = True
            if in_table:
                out.append('')
                in_table = None
            out.append('* ' + _clean(it['text']))
        elif t == 'spec':
            if not has_bar:
                gap()
                out.append('## TECHNICAL SPECIFICATIONS')
                has_bar = True
            if in_table and in_table != 2:
                out.append('')
            in_table = 2
            out.append(_clean(it['cells'][0]) + ' | ' + _clean(it['cells'][1]))
        elif t == 'row':
            if not has_bar:
                gap()
                out.append('## TECHNICAL DATA')
                has_bar = True
            if in_table != len(it['cells']):
                if in_table:
                    out.append('')
                in_table = len(it['cells'])
            out.append(' | '.join(_clean(c) for c in it['cells']))
    tidy = []
    for i, l in enumerate(out):
        if l.startswith('## '):
            j = i + 1
            while j < len(out) and out[j] == '':
                j += 1
            if j >= len(out) or out[j].startswith('## '):
                continue
        tidy.append(l)
    tech = _fixt(('\n'.join(overview) + '\n') if overview else '') + re.sub(r'\n{3,}', '\n\n', '\n'.join(tidy)).strip()
    tech = tech[:16000]

    # ---- quotation lines: working area / length / width / thickness first, then power / capacity
    specs = [{'l': _fixt(_clean(i['cells'][0])), 'v': _clean(i['cells'][1])} for i in items if i['t'] == 'spec']
    dim_specs = [s for s in specs if DIMRX.search(s['l']) and not NODIM.search(s['l']) and re.search(r'\d', s['v']) and len(s['v']) <= 70]
    if any(re.search(r'(bending|working|processing|cutting|useful|plate|sheet|table|max)', d['l'], re.I) for d in dim_specs):
        dim_specs = [d for d in dim_specs if not re.match(r'^\s*(length|width|height)\s*$', re.sub(r'[(（].*?[)）]', '', d['l']), re.I)]

    def short_l(l):
        t = re.sub(r'\(.*?\)', '', l).strip()
        f = re.sub(r'^(max(imum)?\.?|processing|useful|cutting|plate|sheet|working|effective|available)\s+', '', t, flags=re.I)
        t = t if (re.match(r'^(size|range|area|table)\b', f, re.I) and f != t) else f
        return t[:1].upper() + t[1:]

    area_lines, lwt, seen = [], [], set()
    for d in dim_specs:
        key = d['l'].lower() + '|' + d['v']
        if key in seen:
            continue
        seen.add(key)
        if re.search(r'\b(area|size|range|table)\b', d['l'], re.I):
            sl = short_l(d['l'])
            area_lines.append('%s: %s' % (sl if re.search(r'area|size|range|table', sl, re.I) else d['l'], d['v']))
        else:
            lwt.append('%s: %s' % (short_l(d['l']), d['v']))
    dim_lines = area_lines[:2] + ([', '.join(lwt[:4])] if lwt else [])
    used = {d['l'] for d in dim_specs}
    others = [('%s: %s' % (s['l'], s['v'])) for s in specs
              if KEYSPEC.search(s['l']) and s['l'] not in used and not DIMRX.search(s['l'])
              and not re.match(r'^(brand|model|country)', s['l'], re.I) and len(s['v']) <= 60][:max(2, 5 - len(dim_lines))]
    qlines = (dim_lines + others)[:6]
    if len(qlines) < 2 and overview:
        qlines = (qlines + re.split(r'(?<=\.)\s+', overview[0])[:2])[:4]

    T = title.upper() if title else ''
    tech_title = (('%s, MODEL %s' % (T, model.upper())) if (model and model.upper() not in T) else T) if T else (('MODEL ' + model) if model else '')
    no_text = [p['num'] for p in pages if sum(len(' '.join(r['cells'])) for r in p['rows']) < 40]
    return {
        'title': T, 'model': model, 'category': category or T, 'tech_title': tech_title, 'make': make, 'origin': origin,
        'lines': '\n'.join(qlines), 'tech': tech, 'removed': removed, 'no_text_pages': no_text,
        'stats': {'specs': len(specs), 'bullets': sum(1 for i in items if i['t'] == 'bullet'), 'sections': sum(1 for i in items if i['t'] == 'bar'),
                  'tables': sum(1 for i in items if i['t'] == 'row'), 'removed': len(removed), 'pages': len(pages)},
    }


# ------------------------------------------------------------------ which catalog section does a machine belong to?
SECTION_KEYWORDS = [
    ('wood', r"wood|timber|panel\s*saw|beam\s*saw|edge\s*band|edge\s*sand|cnc\s*router|sliding\s*table|veneer|furniture|mdf|plywood|thickness\s*planer|moulder|molder"),
    ('aluminium', r"alumin|mitre|miter|window|curtain\s*wall|pvc|profile\s*(cutting|saw|machine)|double.?head|crimping|corner\s*clean|extrusion"),
    ('special', r"compressor|dust\s*collector|spot\s*weld|welding|generator|filter|crane|boiler|robot|chiller|conveyor|vacuum|polishing|deburr"),
]


def guess_section(text):
    t = (text or '').lower()
    for key, rx in SECTION_KEYWORDS:
        if re.search(rx, t):
            return key
    return 'steel'
