# -*- coding: utf-8 -*-
import io
import json
import shutil
import tempfile
import zipfile

from django.conf import settings as dj_settings
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from PIL import Image

from . import pdfgen, services
from .models import Machine, MachinePage, Offer, OfferTitle, SiteSettings

_MEDIA = tempfile.mkdtemp(prefix='invotex_test_media_')


def tearDownModule():
    shutil.rmtree(_MEDIA, ignore_errors=True)


@override_settings(MEDIA_ROOT=_MEDIA)
class OfferMakerTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('tester', password='pw-12345-xyz')
        services.load_default_catalog()
        services.seed_default_titles()

    def setUp(self):
        self.client.login(username='tester', password='pw-12345-xyz')

    def _post_offer(self, **over):
        slugs = list(Machine.objects.values_list('slug', flat=True)[:2])
        lines = [{'id': slugs[0], 'qty': 2, 'unit_price': '1,000.50', 'lead_time': '8 weeks'},
                 {'id': slugs[1], 'qty': 1, 'unit_price': '2500', 'lead_time': ''}]
        data = {'company': 'ACME Steel LLC', 'attention': 'Mr Ali', 'location': 'Sharjah', 'offer_no': 'INVMCOFR261027-01',
                'date': '27-10-2026', 'validity_days': 7, 'title': '', 'delivery_area': 'RAK', 'origin': '',
                'discount_pct': '5', 'lines_json': json.dumps(lines), 'action': 'save'}
        data.update(over)
        return self.client.post(reverse('offers:new'), data)

    def test_login_required(self):
        self.client.logout()
        r = self.client.get(reverse('offers:list'))
        self.assertEqual(r.status_code, 302)
        self.assertIn('/accounts/login/', r['Location'])

    def test_default_catalog_loaded_once(self):
        self.assertEqual(Machine.objects.count(), 10)
        self.assertTrue(all(m.image for m in Machine.objects.all()))
        self.assertEqual(services.load_default_catalog(), 0)

    def test_create_offer_and_counter(self):
        site = SiteSettings.load()
        first = services.next_offer_no(site)
        r = self._post_offer(offer_no=first)
        self.assertEqual(r.status_code, 302)
        offer = Offer.objects.get(offer_no=first)
        self.assertEqual(offer.lines[0]['unit_price'], '1000.50')
        self.assertEqual(offer.title, site.default_title)
        self.assertNotEqual(services.next_offer_no(site), first)

    def test_duplicate_offer_number_rejected(self):
        self._post_offer()
        r = self._post_offer()
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Offer.objects.count(), 1)

    def test_title_dropdown_comes_from_database(self):
        self.assertTrue(OfferTitle.objects.filter(name='SHEET METAL WORKING MACHINES').exists())
        r = self.client.get(reverse('offers:new'))
        self.assertContains(r, '<select name="title"')
        self.assertContains(r, 'SHEET METAL WORKING MACHINES')
        # a title added through the Titles page shows up in the dropdown and is accepted
        r = self.client.post(reverse('offers:titles'), {'name': 'LASER CUTTING LINES', 'sort_order': '5'})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(OfferTitle.objects.filter(name='LASER CUTTING LINES').exists())
        self.assertContains(self.client.get(reverse('offers:new')), 'LASER CUTTING LINES')
        self.assertEqual(self._post_offer(title='LASER CUTTING LINES').status_code, 302)
        self.assertEqual(Offer.objects.get().title, 'LASER CUTTING LINES')

    def test_title_not_in_database_is_rejected(self):
        self.assertEqual(self._post_offer(title='NOT IN THE LIST').status_code, 200)
        self.assertEqual(Offer.objects.count(), 0)

    def test_deleting_title_keeps_old_offer_title(self):
        self._post_offer(title='WORKSHOP MACHINES')
        t = OfferTitle.objects.get(name='WORKSHOP MACHINES')
        self.client.post(reverse('offers:title_delete', args=[t.pk]))
        offer = Offer.objects.get()
        self.assertEqual(offer.title, 'WORKSHOP MACHINES')
        self.assertContains(self.client.get(reverse('offers:edit', args=[offer.pk])), 'WORKSHOP MACHINES')

    def test_requires_a_machine(self):
        r = self._post_offer(lines_json='[]')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Offer.objects.count(), 0)

    def test_download_word_file(self):
        self._post_offer()
        offer = Offer.objects.get()
        r = self.client.get(reverse('offers:download', args=[offer.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertIn('wordprocessingml', r['Content-Type'])
        z = zipfile.ZipFile(io.BytesIO(b''.join(r.streaming_content)))
        self.assertIsNone(z.testzip())
        xml = z.read('word/document.xml').decode('utf8')
        self.assertIn('ACME Steel LLC', xml)
        self.assertIn('TOTAL PRICE AFTER DISCOUNT', xml)

    def test_catalog_export_import_roundtrip(self):
        buf = services.export_catalog_zip()
        n = services.import_catalog_zip(buf)
        self.assertEqual(n, 10)
        self.assertEqual(Machine.objects.count(), 20)


@override_settings(MEDIA_ROOT=_MEDIA)
class CatalogFeatureTests(TestCase):
    """Create-new title, catalog sections, catalog file import, exact catalogue pages and PDF downloads."""

    @classmethod
    def setUpTestData(cls):
        get_user_model().objects.create_user('tester', password='pw-12345-xyz')
        services.load_default_catalog()
        services.seed_default_titles()

    def setUp(self):
        self.client.login(username='tester', password='pw-12345-xyz')

    # ---- helpers
    def _offer_data(self, **over):
        slug = Machine.objects.values_list('slug', flat=True)[0]
        data = {'company': 'ACME', 'attention': '', 'location': '', 'offer_no': 'INVMCOFR261101-01', 'date': '01-11-2026',
                'validity_days': 7, 'title': 'STEEL WORKING MACHINES', 'new_title': '', 'delivery_area': '', 'origin': '',
                'discount_pct': '0', 'lines_json': json.dumps([{'id': slug, 'qty': 1, 'unit_price': '', 'lead_time': ''}]),
                'action': 'save'}
        data.update(over)
        return data

    def _catalog_pdf(self, slug='laser-1530fp6t240'):
        m = Machine.objects.get(slug=slug)
        return pdfgen.machine_pdf(m.as_engine_dict(), str(dj_settings.OFFER_ASSETS_DIR), m.section_label)

    def _upload(self, name, content, **fields):
        data = {'section': 'wood', 'file': SimpleUploadedFile(name, content)}
        data.update(fields)
        return self.client.post(reverse('offers:catalog_import_file'), data)

    # ---- 1. create new title in the dropdown
    def test_title_dropdown_has_create_new_option(self):
        self.assertContains(self.client.get(reverse('offers:new')), 'value="__new__"')

    def test_create_new_title_from_the_dropdown(self):
        r = self.client.post(reverse('offers:new'), self._offer_data(title='__new__', new_title='  GLASS   MACHINES '))
        self.assertEqual(r.status_code, 302)
        self.assertEqual(Offer.objects.get().title, 'GLASS MACHINES')
        self.assertTrue(OfferTitle.objects.filter(name='GLASS MACHINES').exists())
        self.assertContains(self.client.get(reverse('offers:new')), 'GLASS MACHINES')

    def test_create_new_title_needs_a_name(self):
        r = self.client.post(reverse('offers:new'), self._offer_data(title='__new__', new_title=''))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Offer.objects.count(), 0)

    # ---- 2. sections
    def test_four_sections_and_default_assignment(self):
        r = self.client.get(reverse('offers:machine_list'))
        for label in ('Aluminium machines', 'Steel machines', 'Wood working machines', 'Special machines'):
            self.assertContains(r, label)
        self.assertEqual(Machine.objects.get(slug='compressor-inoair-15kw-vfd').section, 'special')
        self.assertEqual(Machine.objects.get(slug='laser-1530fp6t240').section, 'steel')

    def test_section_filter(self):
        r = self.client.get(reverse('offers:machine_list') + '?section=special')
        self.assertContains(r, 'INOAIR 16 BAR VFD SCREW AIR COMPRESSOR')
        self.assertNotContains(r, 'MANUAL BAND SAW SHARK 281')
        r = self.client.get(reverse('offers:machine_list') + '?section=aluminium')
        self.assertNotContains(r, 'MANUAL BAND SAW SHARK 281')

    # ---- 3. import a catalog file into a section
    def test_import_pdf_into_section(self):
        before = Machine.objects.count()
        r = self._upload('Laser_catalog.pdf', self._catalog_pdf(), section='wood')
        self.assertEqual(r.status_code, 302)
        self.assertEqual(Machine.objects.count(), before + 1)
        m = Machine.objects.order_by('-id').first()
        self.assertEqual(m.section, 'wood')
        self.assertTrue(m.title)
        self.assertFalse(m.use_catalog_pages)
        self.assertTrue(m.source_file)

    def test_import_picture_and_text(self):
        buf = io.BytesIO()
        Image.new('RGB', (400, 300), (30, 90, 160)).save(buf, 'JPEG')
        self.assertEqual(self._upload('router_photo.jpg', buf.getvalue(), section='aluminium').status_code, 302)
        m = Machine.objects.order_by('-id').first()
        self.assertEqual((m.section, bool(m.image)), ('aluminium', True))
        txt = b'Model: ZX-900\nWorking area | 1200 x 800 mm\nMotor power | 7.5 kW\n'
        self.assertEqual(self._upload('zx900.txt', txt, section='special').status_code, 302)
        self.assertEqual(Machine.objects.order_by('-id').first().section, 'special')

    def test_import_rejects_unsupported_files(self):
        before = Machine.objects.count()
        self._upload('old.doc', b'not really word')
        self._upload('archive.zip', b'PK')
        self.assertEqual(Machine.objects.count(), before)

    # ---- 4. technical specification exactly as uploaded
    def test_import_with_exact_pages(self):
        r = self._upload('Laser_catalog.pdf', self._catalog_pdf(), section='steel', as_is='on')
        self.assertEqual(r.status_code, 302)
        m = Machine.objects.order_by('-id').first()
        self.assertTrue(m.use_catalog_pages)
        self.assertGreaterEqual(m.pages.count(), 1)
        self.assertTrue(all(p.image.name.endswith('.jpg') for p in m.pages.all()))

    def test_machine_form_exact_pages(self):
        m = Machine.objects.get(slug='shear-bsy3100-6mm')
        url = reverse('offers:machine_edit', args=[m.pk])
        base = {'section': 'steel', 'category': m.category, 'model_no': m.model_no, 'title': m.title, 'tech_title': m.tech_title,
                'make': m.make, 'origin': m.origin, 'image_width': 3.0, 'image_max_h': 2.3, 'lines': m.lines, 'tech': m.tech}
        # ticked without any pages -> refused
        r = self.client.post(url, dict(base, use_catalog_pages='on'))
        self.assertEqual(r.status_code, 200)
        m.refresh_from_db()
        self.assertFalse(m.use_catalog_pages)
        # ticked with a file -> pages stored
        r = self.client.post(url, dict(base, use_catalog_pages='on', catalog_file=SimpleUploadedFile('c.pdf', self._catalog_pdf())))
        self.assertEqual(r.status_code, 302)
        m.refresh_from_db()
        self.assertTrue(m.use_catalog_pages)
        self.assertGreaterEqual(m.pages.count(), 1)
        # remove the pages again
        r = self.client.post(url, dict(base, clear_pages='on'))
        self.assertEqual(r.status_code, 302)
        m.refresh_from_db()
        self.assertFalse(m.use_catalog_pages)
        self.assertEqual(m.pages.count(), 0)

    def test_exact_pages_go_into_the_word_offer(self):
        m = Machine.objects.get(slug='laser-1530fp6t240')
        pages = [Image.new('RGB', (900, 1270), (240, 240, 240)), Image.new('RGB', (900, 1270), (220, 230, 240))]
        services.store_pages(m, pages)
        m.use_catalog_pages = True
        m.save()
        self.assertEqual(self.client.post(reverse('offers:new'), self._offer_data(lines_json=json.dumps(
            [{'id': m.slug, 'qty': 1, 'unit_price': '', 'lead_time': ''}]))).status_code, 302)
        r = self.client.get(reverse('offers:download', args=[Offer.objects.get().pk]))
        z = zipfile.ZipFile(io.BytesIO(b''.join(r.streaming_content)))
        xml = z.read('word/document.xml').decode('utf8')
        self.assertIn('(PAGE 1 OF 2)', xml)
        self.assertIn('(PAGE 2 OF 2)', xml)

    def test_backup_keeps_sections_and_pages(self):
        m = Machine.objects.get(slug='lathe-cz1440g1')
        m.section = 'aluminium'
        m.use_catalog_pages = True
        m.save()
        services.store_pages(m, [Image.new('RGB', (600, 800), (200, 200, 200))])
        buf = services.export_catalog_zip()
        names = zipfile.ZipFile(buf).namelist()
        self.assertTrue(any(n.startswith('pages/') for n in names))
        buf.seek(0)
        before = Machine.objects.count()
        self.assertEqual(services.import_catalog_zip(buf), before)
        copy = Machine.objects.exclude(pk=m.pk).filter(title=m.title, section='aluminium').first()
        self.assertIsNotNone(copy)
        self.assertTrue(copy.use_catalog_pages)
        self.assertEqual(copy.pages.count(), 1)

    # ---- 5. PDF downloads
    def test_pdf_of_one_machine(self):
        m = Machine.objects.get(slug='laser-1530fp6t240')
        r = self.client.get(reverse('offers:machine_pdf', args=[m.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r['Content-Type'], 'application/pdf')
        self.assertTrue(b''.join(r.streaming_content).startswith(b'%PDF'))

    def test_pdf_of_exact_pages_machine(self):
        m = Machine.objects.get(slug='laser-1530fp6t240')
        services.store_pages(m, [Image.new('RGB', (900, 1270), (240, 240, 240))])
        m.use_catalog_pages = True
        m.save()
        r = self.client.get(reverse('offers:machine_pdf', args=[m.pk]))
        self.assertTrue(b''.join(r.streaming_content).startswith(b'%PDF'))

    def test_pdf_of_sections(self):
        for key in ('steel', 'special', 'wood', 'all'):
            r = self.client.get(reverse('offers:section_pdf', args=[key]))
            self.assertEqual(r.status_code, 200, key)
            self.assertTrue(b''.join(r.streaming_content).startswith(b'%PDF'), key)
        self.assertEqual(self.client.get(reverse('offers:section_pdf', args=['nonsense'])).status_code, 404)

    def test_new_pages_need_login(self):
        self.client.logout()
        m = Machine.objects.first()
        for url in (reverse('offers:machine_pdf', args=[m.pk]), reverse('offers:section_pdf', args=['steel'])):
            self.assertEqual(self.client.get(url).status_code, 302)
