# -*- coding: utf-8 -*-
"""PDF catalogs: one machine data sheet, or a whole catalog section.

Pure python (reportlab + Pillow), no Django imports. Machines are plain dicts:
  {'title', 'model', 'category', 'tech_title', 'make', 'origin', 'image' (path or ''), 'image_width', 'image_max_h',
   'lines', 'tech', 'catalog_pages': [paths]  # only when the technical pages must be used exactly as uploaded}
"""
import io
import os
import re
import datetime
from xml.sax.saxutils import escape

from PIL import Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm, inch
from reportlab.platypus import (BaseDocTemplate, Frame, Image as RLImage, KeepTogether, PageBreak, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

from .engine import parse_markup

NAVY = colors.HexColor('#16365D')
MID = colors.HexColor('#4F81BD')
MAROON = colors.HexColor('#691A28')
GREY = colors.HexColor('#F1F1F1')
LINE = colors.HexColor('#D9DFE7')
COMPANY = 'INVOTEX INDUSTRIAL PLANT EQUIPMENT TRADING LLC'
ADDRESS = 'PO BOX 76497, DUBAI, UAE  |  sales@invotexmachinery.com  |  www.invotexmachinery.com'

_REPLACE = {'≥': '>=', '≤': '<=', '≈': '~', 'φ': 'phi', 'Φ': 'phi', 'Ω': 'ohm', 'µ': 'u', '✓': 'Yes', '✔': 'Yes', '❑': '-',
            '→': '->', '“': '"', '”': '"', '’': "'", '‘': "'", '\u00a0': ' ', '\u2009': ' ', '\u200b': ''}


def safe(text):
    """Text the built-in PDF fonts can print (Latin-1 plus a few common technical symbols)."""
    t = str(text if text is not None else '')
    for a, b in _REPLACE.items():
        t = t.replace(a, b)
    return t.encode('cp1252', 'replace').decode('cp1252')


def _rich(text):
    """'**bold**' markers -> <b>, everything else escaped."""
    out = ''
    for part in re.split(r'(\*\*[^*]+\*\*)', safe(text)):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**') and len(part) > 4:
            out += '<b>%s</b>' % escape(part[2:-2])
        else:
            out += escape(part)
    return out


# ------------------------------------------------------------------ styles
def _styles():
    base = dict(fontName='Helvetica', fontSize=9, leading=12, textColor=colors.HexColor('#202020'), alignment=TA_LEFT)
    return {
        'body': ParagraphStyle('body', spaceBefore=3, spaceAfter=3, **base),
        'cell': ParagraphStyle('cell', **dict(base, fontSize=8.5, leading=10.5)),
        'cellb': ParagraphStyle('cellb', **dict(base, fontSize=8.5, leading=10.5, fontName='Helvetica-Bold', textColor=colors.white)),
        'bar': ParagraphStyle('bar', **dict(base, fontName='Helvetica-Bold', fontSize=9, textColor=MAROON)),
        'bullet': ParagraphStyle('bullet', leftIndent=14, bulletIndent=3, spaceBefore=2, **base),
        'note': ParagraphStyle('note', **dict(base, fontName='Helvetica-Oblique', fontSize=7.5, leading=9.5, spaceBefore=4)),
        'title': ParagraphStyle('title', **dict(base, fontName='Helvetica-Bold', fontSize=13, leading=16, textColor=NAVY, spaceAfter=4)),
        'sub': ParagraphStyle('sub', **dict(base, fontSize=9, textColor=colors.HexColor('#56677C'), spaceAfter=6)),
        'cover': ParagraphStyle('cover', **dict(base, fontName='Helvetica-Bold', fontSize=24, leading=30, textColor=NAVY, spaceAfter=10)),
        'toc': ParagraphStyle('toc', **dict(base, fontSize=10, leading=15)),
    }


# ------------------------------------------------------------------ page decoration
def _decorate(logo_path, heading):
    def draw(canvas, doc):
        w, h = A4
        canvas.saveState()
        canvas.setFillColor(NAVY)
        canvas.rect(0, h - 16 * mm, w, 16 * mm, fill=1, stroke=0)
        if logo_path and os.path.exists(logo_path):
            try:
                iw, ih = Image.open(logo_path).size
                lh = 10 * mm
                canvas.setFillColor(colors.white)
                canvas.roundRect(12 * mm, h - 13 * mm, lh * iw / ih + 4 * mm, lh, 1.5 * mm, fill=1, stroke=0)
                canvas.drawImage(logo_path, 14 * mm, h - 13 * mm + 1 * mm, width=lh * iw / ih, height=lh - 2 * mm,
                                 preserveAspectRatio=True, mask='auto')
            except Exception:
                pass
        canvas.setFillColor(colors.white)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawRightString(w - 12 * mm, h - 9.5 * mm, safe(heading).upper())
        canvas.setStrokeColor(NAVY)
        canvas.setLineWidth(0.6)
        canvas.line(12 * mm, 14 * mm, w - 12 * mm, 14 * mm)
        canvas.setFillColor(colors.HexColor('#444444'))
        canvas.setFont('Helvetica', 7)
        canvas.drawString(12 * mm, 10 * mm, COMPANY)
        canvas.drawString(12 * mm, 6.5 * mm, ADDRESS)
        canvas.drawRightString(w - 12 * mm, 10 * mm, 'Page %d' % doc.page)
        canvas.restoreState()
    return draw


def _doc(buf, logo, heading, title):
    doc = BaseDocTemplate(buf, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=22 * mm, bottomMargin=20 * mm,
                          title=safe(title), author='Invotex')
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='f', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id='p', frames=[frame], onPage=_decorate(logo, heading))])
    return doc


# ------------------------------------------------------------------ flowables for one machine
def _picture(path, max_w_mm, max_h_mm):
    try:
        iw, ih = Image.open(path).size
    except Exception:
        return None
    w, h = max_w_mm * mm, max_w_mm * mm * ih / iw
    if h > max_h_mm * mm:
        h = max_h_mm * mm
        w = h * iw / ih
    img = RLImage(path, width=w, height=h)
    img.hAlign = 'CENTER'
    return img


def _widths(n, total, spec=None):
    if spec and len(spec) == n and sum(spec):
        w = [total * x / float(sum(spec)) for x in spec]
        return w
    if n == 1:
        return [total]
    if n == 2:
        return [total * 0.40, total * 0.60]
    first = total * (0.26 if n <= 5 else 0.18)
    rest = (total - first) / (n - 1)
    return [first] + [rest] * (n - 1)


def machine_flowables(m, st, width):
    """The data sheet of one machine as a list of flowables (title, picture, overview, tables ...)."""
    fl = []
    title = m.get('tech_title') or ('%s, MODEL %s' % (m.get('title', ''), m.get('model', '')))
    fl.append(Paragraph(escape(safe(title).upper()), st['title']))
    info = []
    if m.get('section_label'):
        info.append(m['section_label'])
    mk = re.sub(r'^\s*Make:\s*', '', m.get('make') or '')
    if mk:
        info.append('Brand: ' + mk)
    if m.get('origin') and (m.get('origin') or '').lower() not in mk.lower():
        info.append('Country of origin: ' + m['origin'])
    if info:
        fl.append(Paragraph(escape(safe('   |   '.join(info))), st['sub']))
    img = m.get('image')
    if img and os.path.exists(img):
        p = _picture(img, float(m.get('image_width') or 3.0) * 25.4, float(m.get('image_max_h') or 2.3) * 25.4)
        if p:
            fl += [p, Spacer(1, 4 * mm)]
    for kind, val in parse_markup(m.get('tech', '')):
        if kind == 'bar':
            t = Table([[Paragraph(escape(safe(val)), st['bar'])]], colWidths=[width])
            t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), GREY), ('BOX', (0, 0), (-1, -1), 0.4, LINE),
                                   ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3), ('LEFTPADDING', (0, 0), (-1, -1), 6)]))
            fl += [Spacer(1, 3 * mm), t]
        elif kind == 'table':
            head, rows = val['head'], val['rows']
            if head is None:
                head, rows = rows[0], rows[1:]
            n = len(head)
            data = [[Paragraph(_rich(c), st['cellb']) for c in head]]
            for r in rows:
                r = list(r)
                if len(r) > n:
                    r = r[:n - 1] + [' | '.join(r[n - 1:])]
                r += [''] * (n - len(r))
                data.append([Paragraph(_rich(c), st['cell']) for c in r])
            t = Table(data, colWidths=_widths(n, width, val.get('widths')), repeatRows=1)
            t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), NAVY), ('GRID', (0, 0), (-1, -1), 0.3, LINE),
                                   ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
            fl.append(t)
        elif kind == 'bullet':
            fl.append(Paragraph(_rich(val), st['bullet'], bulletText='\u2022'))
        elif kind == 'note':
            fl.append(Paragraph(escape(safe(val)), st['note']))
        else:
            fl.append(Paragraph(_rich(val), st['body']))
    return fl


def _page_image_flowable(path, width, height):
    """A catalogue page picture fitted to the frame (kept exactly as uploaded)."""
    iw, ih = Image.open(path).size
    s = min(width / float(iw), height / float(ih))
    img = RLImage(path, width=iw * s, height=ih * s)
    img.hAlign = 'CENTER'
    return img


# ------------------------------------------------------------------ public API
def machine_pdf(m, assets_dir, section_label=''):
    """PDF bytes: the machine data sheet. If the machine uses its catalogue pages as they are, those pages are the PDF."""
    st = _styles()
    buf = io.BytesIO()
    logo = os.path.join(assets_dir, 'logo.jpg')
    doc = _doc(buf, logo, section_label or 'Machine catalog', m.get('title', 'Machine'))
    story = _machine_story(m, st, doc, section_label)
    doc.build(story)
    return buf.getvalue()


def _machine_story(m, st, doc, section_label):
    pages = [p for p in (m.get('catalog_pages') or []) if os.path.exists(p)]
    if pages:
        story = [Paragraph(escape(safe(m.get('title', ''))), st['sub'])]
        fw, fh = doc.width, doc.height - 8 * mm
        for i, p in enumerate(pages):
            if i:
                story.append(PageBreak())
            story.append(_page_image_flowable(p, fw, fh))
        return story
    mm_ = dict(m)
    mm_['section_label'] = section_label
    return machine_flowables(mm_, st, doc.width)


def section_pdf(machines, assets_dir, section_label):
    """PDF bytes: a cover page, a contents list and every machine of the section."""
    st = _styles()
    buf = io.BytesIO()
    logo = os.path.join(assets_dir, 'logo.jpg')
    doc = _doc(buf, logo, section_label + ' catalog', section_label + ' catalog')
    story = [Spacer(1, 30 * mm), Paragraph(escape(safe(section_label)), st['cover']),
             Paragraph('Machine catalog', st['title']),
             Paragraph(escape(safe('%d machine%s  -  %s' % (len(machines), '' if len(machines) == 1 else 's', datetime.date.today().strftime('%d-%m-%Y')))), st['sub']),
             Spacer(1, 10 * mm)]
    if machines:
        story.append(Paragraph('Contents', st['bar']))
        for i, m in enumerate(machines, 1):
            story.append(Paragraph(escape(safe(('%d.  %s %s' % (i, m.get('model', ''), m.get('title', ''))).replace('  ', ' '))), st['toc']))
    else:
        story.append(Paragraph('There are no machines in this section yet.', st['body']))
    for m in machines:
        story.append(PageBreak())
        story += _machine_story(m, st, doc, section_label)
    doc.build(story)
    return buf.getvalue()
