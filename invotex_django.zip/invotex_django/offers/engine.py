# -*- coding: utf-8 -*-
"""Invotex Offer Maker - document engine (same logic as the desktop version).
Builds a .docx offer in the Invotex format from the bundled template, the machine
catalog and the offer details. Pure python (lxml + Pillow)."""
import copy, os, re, shutil, tempfile, zipfile, io
from xml.sax.saxutils import escape
from lxml import etree
from PIL import Image

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
q = lambda t: '{%s}%s' % (W, t)
NSDECL = ('xmlns:w="%s" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
          'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
          'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
          'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"') % W

NAVY = '16365D'; MID = '4F81BD'; MAROON = '691A28'; PAGE_BORDER = '16365D'
TW = 9813; IND = 228


class OfferError(Exception):
    pass


# ------------------------------------------------------------------ markup
def parse_markup(text):
    """Technical page markup -> list of blocks.
    '## Title' section bar | 'a | b' table row | '# h1 | h2 {40,60}' table header (optional % widths)
    '* text' bullet (use **bold**) | '> text' italic note | other lines = paragraph."""
    blocks = []
    pending_head = None
    table = None
    for raw in (text or '').splitlines():
        line = raw.rstrip()
        if not line.strip():
            table = None
            continue
        s = line.strip()
        if s.startswith('## '):
            blocks.append(('bar', s[3:].strip())); table = None; pending_head = None
        elif s.startswith('# '):
            body = s[2:]
            widths = None
            m = re.search(r'\{([0-9, ]+)\}\s*$', body)
            if m:
                widths = [int(x) for x in m.group(1).split(',') if x.strip()]
                body = body[:m.start()]
            pending_head = ([c.strip() for c in body.split('|')], widths)
            table = None
        elif s.startswith('* ') or s.startswith('- '):
            blocks.append(('bullet', s[2:].strip())); table = None
        elif s.startswith('> '):
            blocks.append(('note', s[2:].strip())); table = None
        elif '|' in s:
            cells = [c.strip() for c in s.split('|')]
            if table is None:
                if pending_head:
                    head, widths = pending_head; pending_head = None
                else:
                    head, widths = (['Parameter', 'Specification'] if len(cells) == 2 else None), None
                table = {'head': head, 'widths': widths, 'rows': []}
                blocks.append(('table', table))
            table['rows'].append(cells)
        else:
            blocks.append(('para', s)); table = None
    return blocks


# ------------------------------------------------------------------ builder
class Builder:
    def __init__(self, template, assets_dir):
        self.assets = assets_dir
        self.tmp = tempfile.mkdtemp(prefix='invotex_')
        self.u = os.path.join(self.tmp, 'u')
        with zipfile.ZipFile(template) as z:
            z.extractall(self.u)
        self.rels = open(os.path.join(self.u, 'word/_rels/document.xml.rels'), encoding='utf8').read()
        self.rid_n = 100
        self.docpr = 2000
        self.media_n = 0
        self.img_cache = {}
        self.doc = etree.parse(os.path.join(self.u, 'word/document.xml'))
        self.body = self.doc.getroot().find('w:body', NS)
        self.els = list(self.body)

    # ---- media
    def add_image(self, path, max_w=1500):
        key = os.path.abspath(path)
        if key in self.img_cache:
            return self.img_cache[key]
        im = Image.open(path).convert('RGB')
        if im.width > max_w:
            im = im.resize((max_w, int(im.height * max_w / im.width)), Image.LANCZOS)
        self.media_n += 1
        name = 'om_img%d.jpeg' % self.media_n
        im.save(os.path.join(self.u, 'word/media', name), quality=92, subsampling=0)
        rid = 'rId%d' % self.rid_n; self.rid_n += 1
        self.rels = self.rels.replace('</Relationships>',
            '<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/%s"/></Relationships>' % (rid, name))
        self.img_cache[key] = (rid, im.size)
        return self.img_cache[key]

    def inline(self, path, width_in, maxh=None):
        rid, (w, h) = self.add_image(path)
        cx = int(width_in * 914400); cy = int(cx * h / w)
        if maxh and cy > maxh * 914400:
            cy = int(maxh * 914400); cx = int(cy * w / h)
        self.docpr += 1; i = self.docpr
        return ('<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="%d" cy="%d"/>'
                '<wp:docPr id="%d" name="Picture %d" descr="Machine photo"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
                '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="%d" name="img%d.jpg"/><pic:cNvPicPr/></pic:nvPicPr>'
                '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
                '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>'
                ) % (cx, cy, i, i, i, i, rid, cx, cy)

    # ---- xml helpers
    @staticmethod
    def R(t, b=False, color='202020', sz=18, hl=False, i=False):
        rp = ('<w:b/><w:bCs/>' if b else '') + ('<w:i/>' if i else '') + ('<w:color w:val="%s"/>' % color if color else '') \
            + '<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (sz, sz) + ('<w:highlight w:val="yellow"/>' if hl else '')
        return '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (rp, escape(t))

    def rich(self, s, sz=18, color='202020', hl_brackets=False):
        """**bold** markup and [yellow placeholders]."""
        out = ''
        for k, part in enumerate(re.split(r'(\*\*[^*]+\*\*)', s)):
            if not part: continue
            if part.startswith('**') and part.endswith('**'):
                out += self.R(part[2:-2], b=True, sz=sz, color=color)
            elif hl_brackets and '[' in part:
                for sub in re.split(r'(\[[^\]]*\])', part):
                    if sub: out += self.R(sub, sz=sz, color=color, hl=(sub.startswith('[') and sub.endswith(']')))
            else:
                out += self.R(part, sz=sz, color=color)
        return out

    @staticmethod
    def P(runs, ind=144, before=0, line=276, jc=None, keep=False, after=None, style='TableParagraph'):
        pp = '<w:pStyle w:val="%s"/>' % style + ('<w:keepNext/>' if keep else '') + \
             '<w:spacing w:before="%d"%s w:line="%d" w:lineRule="auto"/>' % (before, '' if after is None else ' w:after="%d"' % after, line) + \
             ('<w:ind w:left="%d"/>' % ind if ind else '') + ('<w:jc w:val="%s"/>' % jc if jc else '')
        return '<w:p><w:pPr>%s</w:pPr>%s</w:p>' % (pp, runs)

    def PAGEHEAD(self, t):
        return ('<w:p><w:pPr><w:keepNext/><w:spacing w:before="417"/><w:ind w:left="228"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="%s"/><w:sz w:val="25"/></w:rPr><w:t>%s</w:t></w:r></w:p>') % (MAROON, escape(t))

    def BULLET(self, runs):
        return ('<w:p><w:pPr><w:pStyle w:val="ListParagraph"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="2"/></w:numPr><w:tabs><w:tab w:val="left" w:pos="423"/></w:tabs>'
                '<w:spacing w:before="50"/><w:ind w:left="651" w:hanging="107"/></w:pPr>%s</w:p>') % runs

    @staticmethod
    def tbl(grid, rows):
        g = ''.join('<w:gridCol w:w="%d"/>' % x for x in grid)
        bd = ''.join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="DFDFDF"/>' % s for s in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'))
        return ('<w:tbl><w:tblPr><w:tblW w:w="%d" w:type="dxa"/><w:tblInd w:w="%d" w:type="dxa"/><w:tblBorders>%s</w:tblBorders><w:tblLayout w:type="fixed"/>'
                '<w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="01E0"/></w:tblPr><w:tblGrid>%s</w:tblGrid>%s</w:tbl>') % (sum(grid), IND, bd, g, ''.join(rows))

    @staticmethod
    def TC(w, content, fill=None, span=None):
        return '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s%s<w:vAlign w:val="center"/></w:tcPr>%s</w:tc>' % (
            w, '<w:gridSpan w:val="%d"/>' % span if span else '', '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % fill if fill else '', content)

    @staticmethod
    def TR(cells, header=False):
        return '<w:tr><w:trPr><w:cantSplit/>%s</w:trPr>%s</w:tr>' % ('<w:tblHeader/>' if header else '', ''.join(cells))

    def hdr_row(self, grid, labels):
        return self.TR([self.TC(w, self.P(self.R(l, b=True, color='FFFFFF', sz=15), before=30, after=30, line=240, ind=100), fill='16365D') for w, l in zip(grid, labels)], header=True)

    def row(self, grid, vals, boldfirst=False):
        return self.TR([self.TC(w, self.P(self.rich(v, sz=18) if not (boldfirst and i == 0) else self.R(v, b=True), before=20, after=20, line=240, ind=100))
                        for i, (w, v) in enumerate(zip(grid, vals))])

    def bar(self, t):
        return self.tbl([TW], [self.TR([self.TC(TW, self.P(self.R(t, b=True, color=MAROON, sz=17), before=60, after=60, line=240, ind=124, keep=True), fill='F1F1F1')])])

    def spacer(self):
        return self.P('', before=0, line=120, ind=0)

    def img_par(self, path, w, maxh=None):
        return '<w:p><w:pPr><w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="center"/></w:pPr>%s</w:p>' % self.inline(path, w, maxh)

    def frag(self, xml):
        r = etree.fromstring('<w:root %s>%s</w:root>' % (NSDECL, xml))
        return list(r)

    def widths_for(self, n, widths):
        if widths and len(widths) == n:
            g = [int(TW * x / sum(widths)) for x in widths]; g[-1] += TW - sum(g); return g
        if n == 1: return [TW]
        if n == 2: return [3500, TW - 3500]
        first = 2813 if n <= 5 else 1500
        rest = (TW - first) // (n - 1)
        g = [first] + [rest] * (n - 1); g[-1] += TW - sum(g); return g

    # ---- technical page
    def tech_pages_section(self, number, m):
        """The uploaded catalogue pages, exactly as they are (one picture per page, same page header as the other machines)."""
        title = m.get('tech_title') or ('%s, MODEL %s' % (m.get('title', ''), m.get('model', '')))
        cap = 'MACHINE %d – %s' % (number, title.upper())
        pages = m['_catalog_pages']
        mk = re.sub(r'^\s*Make:\s*', '', m.get('make') or '').strip()
        parts_ = [x.strip() for x in mk.split(',') if x.strip()]
        brand = parts_[0] if parts_ else ''
        origin = (m.get('origin') or '').strip() or (parts_[1] if len(parts_) > 1 else '')
        info = '   ·   '.join(x for x in ('Brand: ' + brand if brand else '', 'Country of origin: ' + origin if origin else '') if x)
        out = []
        for i, p in enumerate(pages):
            out.append(self.PAGEHEAD('TECHNICAL SPECIFICATIONS'))
            out.append(self.P(self.R(cap + (' (PAGE %d OF %d)' % (i + 1, len(pages)) if len(pages) > 1 else ''), b=True, sz=20),
                              ind=228, before=40, line=276, keep=True))
            if i == 0 and info:
                out.append(self.P(self.R(info, sz=17), ind=228, before=20, line=240, keep=True))
            out.append(self.img_par(p, 6.6, 7.9 if (i == 0 and info) else 8.2))
            out.append(self.sect_par())
        return ''.join(out)

    def tech_section(self, number, m):
        if m.get('_catalog_pages'):
            return self.tech_pages_section(number, m)
        title = m.get('tech_title') or ('%s, MODEL %s' % (m.get('title', ''), m.get('model', '')))
        parts = [self.PAGEHEAD('TECHNICAL SPECIFICATIONS'),
                 self.P(self.R('MACHINE %d – %s' % (number, title.upper()), b=True, sz=20), ind=228, before=40, line=276, keep=True)]
        img = m.get('_image_path')
        if img:
            parts.append(self.img_par(img, float(m.get('image_width', 3.0) or 3.0), float(m.get('image_max_h', 2.3) or 2.3)))
        first_bar = True
        for kind, val in parse_markup(m.get('tech', '')):
            if kind == 'bar':
                parts.append(self.spacer()); parts.append(self.bar(val))
            elif kind == 'table':
                rows = val['rows']; head = val['head']
                if head is None:
                    head, rows = rows[0], rows[1:]
                n = len(head)
                def fit(r):
                    r = list(r)
                    if len(r) > n: r = r[:n - 1] + [' | '.join(r[n - 1:])]
                    return r + [''] * (n - len(r))
                g = self.widths_for(n, val['widths'])
                body = [self.hdr_row(g, head)] + [self.row(g, fit(r)) for r in rows]
                parts.append(self.tbl(g, body))
            elif kind == 'bullet':
                parts.append(self.BULLET(self.rich(val)))
            elif kind == 'note':
                parts.append(self.P(self.R(val, i=True, sz=15), ind=228, before=60, line=240))
            else:
                parts.append(self.P(self.rich(val), ind=228, before=60, line=276))
        parts.append(self.sect_par())
        return ''.join(parts)

    def sect_par(self):
        s = etree.tostring(self.SECT).decode()
        return '<w:p><w:pPr><w:spacing w:before="0" w:line="20" w:lineRule="exact"/>%s</w:pPr></w:p>' % s

    # ---- quotation helpers
    def setcell(self, tc, text):
        ps = tc.findall('w:p', NS)
        for p in ps[1:]: tc.remove(p)
        p = ps[0]
        for r in p.findall('w:r', NS)[1:]: p.remove(r)
        for e in list(p):
            if e.tag not in (q('pPr'), q('r')): p.remove(e)
        if text is None or text == '':
            for r in p.findall('w:r', NS): p.remove(r)
            return
        r = p.find('w:r', NS)
        for t in r.findall('w:t', NS)[1:]: r.remove(t)
        for e in list(r):
            if e.tag in (q('lastRenderedPageBreak'), q('drawing')): r.remove(e)
        r.find('w:t', NS).text = text

    @staticmethod
    def setcat(tr, text):
        ts = tr.findall('.//w:t', NS)
        ts[0].text = text
        for t in ts[1:]: t.getparent().remove(t)

    def desc_cell(self, tc, title, lines, lead, img):
        for p in tc.findall('w:p', NS): tc.remove(p)
        x = self.P(self.R(title, b=True), ind=144, before=60)
        for l in lines:
            if l.strip(): x += self.P(self.rich(l, hl_brackets=True), ind=144, before=0)
        if lead:
            x += self.P(self.R('Lead time: ') + self.rich(lead, hl_brackets=True), ind=144, before=0)
        if img:
            x += '<w:p><w:pPr><w:pStyle w:val="TableParagraph"/><w:spacing w:before="60"/><w:ind w:left="144"/></w:pPr>%s</w:p>' % self.inline(img, 1.6, 0.95)
        for e in self.frag(x): tc.append(e)

    def add_machine_rows(self, tbl_el, no, m, line):
        c = copy.deepcopy(self.cat_t); self.setcat(c, m.get('category', '').upper() or m.get('title', '').upper()); tbl_el.append(c)
        it = copy.deepcopy(self.item_t); cs = it.findall('w:tc', NS)
        self.setcell(cs[0], str(no)); self.setcell(cs[1], m.get('model', ''))
        for e in cs[1].iter(q('sz'), q('szCs')): e.set(q('val'), '16')
        if m.get('model', '').startswith('['):
            for r in cs[1].iter(q('r')):
                rp = r.find('w:rPr', NS)
                if rp is not None: etree.SubElement(rp, q('highlight')).set(q('val'), 'yellow')
        lines = [l for l in (m.get('lines') or '').splitlines()]
        if m.get('make'): lines.append(m['make'])
        self.desc_cell(cs[2], m.get('title', ''), lines, line.get('lead_time', ''), m.get('_image_path'))
        qty = line.get('qty', 1)
        self.setcell(cs[3], str(qty if qty not in (None, '') else 1))
        up = line.get('unit_price')
        if up not in (None, '', 0):
            self.setcell(cs[4], fmt(up)); self.setcell(cs[5], fmt(float(up) * float(qty or 1)))
            for idx in (4, 5): self.right_align(cs[idx])
        else:
            self.setcell(cs[4], None); self.setcell(cs[5], None)
        it.find('w:trPr/w:trHeight', NS).set(q('val'), '1500')
        tbl_el.append(it)

    @staticmethod
    def right_align(tc):
        p = tc.find('w:p', NS); pPr = p.find('w:pPr', NS)
        if pPr is None: pPr = etree.SubElement(p, q('pPr')); p.insert(0, pPr)
        for j in pPr.findall('w:jc', NS): pPr.remove(j)
        jc = etree.Element(q('jc')); jc.set(q('val'), 'right')
        anchor = None
        for tag in ('rPr', 'sectPr', 'pPrChange'):
            anchor = pPr.find('w:' + tag, NS)
            if anchor is not None: break
        if anchor is not None: anchor.addprevious(jc)
        else: pPr.append(jc)

    def summary_row(self, label, amount, bold=True, fill=None):
        bd = ''.join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="DFDFDF"/>' % s for s in ('top', 'left', 'bottom', 'right'))
        grid = [450, 1400, 4363, 520, 1500, 1580]
        def cell(w, txt, span=None, jc='right'):
            return ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s<w:tcBorders>%s</w:tcBorders>%s<w:vAlign w:val="center"/></w:tcPr>%s</w:tc>') % (
                w, '<w:gridSpan w:val="%d"/>' % span if span else '', bd, '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % fill if fill else '',
                self.P(self.R(txt, b=bold, sz=20), ind=100, before=40, after=40, line=240, jc=jc))
        x = '<w:tr><w:trPr><w:cantSplit/></w:trPr>%s%s</w:tr>' % (cell(sum(grid[:5]), label, span=5), cell(grid[5], amount))
        return self.frag('<w:tbl>%s</w:tbl>' % x)[0].find('w:tr', NS)


def fmt(v):
    try: return '{:,.2f}'.format(float(v))
    except Exception: return str(v)


def plan_pages(n):
    if n <= 2: return [n]
    pages = [2]; rem = n - 2
    while rem > 0:
        take = 3 if rem > 3 else (2 if rem == 3 else rem)
        pages.append(take); rem -= take
    return pages


# ------------------------------------------------------------------ main entry
def generate_offer(offer, catalog_by_id, images_dir, assets_dir, out_path, settings=None):
    """Create the Word offer at out_path. The scratch folder is always removed, even on errors."""
    b = Builder(os.path.join(assets_dir, 'template.docx'), assets_dir)
    try:
        return _build_offer(b, offer, catalog_by_id, images_dir, assets_dir, out_path, settings)
    finally:
        shutil.rmtree(b.tmp, ignore_errors=True)


def _build_offer(b, offer, catalog_by_id, images_dir, assets_dir, out_path, settings=None):
    settings = settings or {}
    els, body, doc = b.els, b.body, b.doc
    # validate template structure
    try:
        t1, t2 = els[28], els[31]
        assert t1.tag == q('tbl') and t2.tag == q('tbl') and els[32].findall('.//w:sectPr', NS)
    except Exception:
        raise OfferError('Template structure not recognised. Please use the template.docx supplied with the program.')
    b.SECT = copy.deepcopy(els[32].find('.//w:sectPr', NS))

    # resolve machines
    lines = []
    for ln in offer.get('lines', []):
        m = dict(catalog_by_id.get(ln['id']) or {})
        if not m: raise OfferError('Machine "%s" is no longer in the catalog.' % ln['id'])
        img = m.get('image')
        if img:
            p = img if os.path.isabs(img) else os.path.join(images_dir, img)
            m['_image_path'] = p if os.path.exists(p) else None
        if m.get('use_catalog_pages'):          # technical pages exactly as uploaded
            pgs = [p for p in (m.get('catalog_pages') or []) if p and os.path.exists(p)]
            if pgs:
                m['_catalog_pages'] = pgs
        lines.append((m, ln))
    if not lines: raise OfferError('Add at least one machine to the offer.')

    # -------- quotation
    r1 = t1.findall('w:tr', NS); r2 = t2.findall('w:tr', NS)
    hdr = copy.deepcopy(r1[0]); b.cat_t = copy.deepcopy(r1[1]); b.item_t = copy.deepcopy(r1[2]); ex_t = copy.deepcopy(r2[4])
    for tpl in (hdr, b.cat_t, b.item_t, ex_t):
        for bm in list(tpl.iter(q('bookmarkStart'), q('bookmarkEnd'))): bm.getparent().remove(bm)
    for tr in r1 + r2: tr.getparent().remove(tr)
    t1.append(hdr)
    pages = plan_pages(len(lines))
    tables = [t1]; no = 0; spacer_tpl = copy.deepcopy(els[30]); sect_tpl = copy.deepcopy(els[32])
    for pi, cnt in enumerate(pages):
        if pi == 0: tb = t1
        elif pi == 1: tb = t2
        else:
            tb = copy.deepcopy(t2)
            for tr in tb.findall('w:tr', NS): tb.remove(tr)
            tables.append(tb)
        if pi == 1: tables.append(t2)
        for _ in range(cnt):
            m, ln = lines[no]; no += 1
            b.add_machine_rows(tb, no, m, ln)
    # remove unused second page
    if len(pages) == 1:
        for e in (els[30], els[31], els[32]): body.remove(e)
    # summary rows on the last table
    last = tables[-1] if len(pages) > 1 else t1
    last = t1 if len(pages) == 1 else (t2 if len(pages) == 2 else tables[-1])
    priced = [(m, ln) for m, ln in lines if ln.get('unit_price') not in (None, '', 0)]
    if priced and len(priced) == len(lines):
        sub = sum(float(ln['unit_price']) * float(ln.get('qty') or 1) for m, ln in lines)
        disc = float(offer.get('discount_pct') or 0)
        cur = settings.get('currency', 'AED')
        if disc > 0:
            last.append(b.summary_row('TOTAL PRICE (%s)' % cur, fmt(sub), bold=False))
            dv = sub * disc / 100.0
            last.append(b.summary_row('SPECIAL DISCOUNT (%s%%)' % ('%g' % disc), fmt(dv), bold=False))
            last.append(b.summary_row('TOTAL PRICE AFTER DISCOUNT (%s)' % cur, fmt(sub - dv), fill='F1F1F1'))
        else:
            last.append(b.summary_row('TOTAL PRICE (%s)' % cur, fmt(sub), fill='F1F1F1'))
    if offer.get('price_basis', settings.get('price_basis', 'EX WORKS PRICE WITHOUT SHIPPING COST')):
        pb = copy.deepcopy(ex_t)
        ts = pb.findall('.//w:t', NS)
        if ts:
            ts[0].text = offer.get('price_basis', settings.get('price_basis', 'EX WORKS PRICE WITHOUT SHIPPING COST'))
            for t in ts[1:]: t.getparent().remove(t)
        last.append(pb)
    # extra pages beyond the two original ones
    pos = list(body).index(els[32]) + 1 if len(pages) > 1 else list(body).index(els[29]) + 1
    for tb in tables[2:]:
        sp = copy.deepcopy(spacer_tpl); sc = copy.deepcopy(sect_tpl)
        for e in (sp, tb, sc):
            for bm in list(e.iter(q('bookmarkStart'), q('bookmarkEnd'))): bm.getparent().remove(bm)
            body.insert(pos, e); pos += 1

    # -------- technical sections
    new = []
    for k, (m, ln) in enumerate(lines, 1):
        new += b.frag(b.tech_section(k, m))
    for k, e in enumerate(new): body.insert(pos + k, e)

    # -------- template text replacements
    origins = []
    for m, ln in lines:
        o = (m.get('origin') or '').strip()
        if o and o not in origins: origins.append(o)
    origin_txt = offer.get('origin') or ', '.join(origins)
    delivery = offer.get('delivery_area') or ''
    for p in body.iter(q('p')):
        txt = ''.join(p.itertext()).strip()
        if txt.startswith('Delivery Area') and delivery: set_par_text(p, 'Delivery Area: ' + delivery)
        elif txt.startswith('Manufacturing Origin') and origin_txt: set_par_text(p, 'Manufacturing Origin: ' + origin_txt)
    extra = settings.get('replacements') or []
    for find, repl in extra:
        for p in body.iter(q('p')):
            if find and find in ''.join(p.itertext()):
                set_par_text(p, ''.join(p.itertext()).replace(find, repl))

    finalize(b, offer, assets_dir)
    doc.write(os.path.join(b.u, 'word/document.xml'), xml_declaration=True, encoding='UTF-8', standalone=True)
    open(os.path.join(b.u, 'word/_rels/document.xml.rels'), 'w', encoding='utf8').write(b.rels)
    # zip
    if os.path.exists(out_path): os.remove(out_path)
    with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = os.path.join(b.u, '[Content_Types].xml')
        z.write(ct, '[Content_Types].xml')
        for rootd, dirs, files in os.walk(b.u):
            for f in files:
                full = os.path.join(rootd, f); arc = os.path.relpath(full, b.u)
                if arc == '[Content_Types].xml': continue
                z.write(full, arc)
    shutil.rmtree(b.tmp, ignore_errors=True)
    return out_path


def set_par_text(p, text):
    runs = [r for r in p.findall('w:r', NS) if r.find('w:t', NS) is not None]
    if not runs: return
    first = runs[0]
    ts = first.findall('w:t', NS); ts[0].text = text; ts[0].set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
    for t in ts[1:]: first.remove(t)
    for r in runs[1:]: r.getparent().remove(r)


# ------------------------------------------------------------------ finishing passes (10pt, cover, header/footer, borders)
def finalize(b, offer, assets):
    u = b.u; body = b.body
    els = list(body)
    cover_end = [i for i, e in enumerate(els) if e.findall('.//w:sectPr', NS)][0]
    # 10pt everywhere except the cover
    def setsz(el):
        for e in el.iter(q('sz'), q('szCs')): e.set(q('val'), '20')
    for e in els[cover_end + 1:]: setsz(e)
    # general conditions compaction + blank paragraphs
    els = list(body)
    for i, e in enumerate(els):
        if e.tag == q('p') and ''.join(e.itertext()).strip().startswith('Acknowledged'):
            k = i - 1; rm = 0
            while rm < 5 and els[k].tag == q('p') and not ''.join(els[k].itertext()).strip() and not els[k].findall('.//w:sectPr', NS) and not els[k].findall('.//w:drawing', NS):
                body.remove(els[k]); k -= 1; rm += 1
    els = list(body)
    hi = [i for i, e in enumerate(els) if ''.join(e.itertext()).strip().startswith('GENERAL')][0]
    for e in els[hi + 1:]:
        if e.tag != q('p'): continue
        txt = ''.join(e.itertext()).strip()
        if not txt and not e.findall('.//w:sectPr', NS):
            sp0 = e.find('w:pPr/w:spacing', NS)
            if sp0 is not None and sp0.get(q('before')): sp0.set(q('before'), '0')
            for z in e.iter(q('sz'), q('szCs')): z.set(q('val'), '8')
            if e.find('w:pPr', NS) is None: etree.SubElement(e, q('pPr'))
            rp = e.find('w:pPr/w:rPr', NS)
            if rp is None: rp = etree.SubElement(e.find('w:pPr', NS), q('rPr'))
            for tag in ('sz', 'szCs'):
                if rp.find('w:' + tag, NS) is None: etree.SubElement(rp, q(tag)).set(q('val'), '8')
        else:
            sp = e.find('w:pPr/w:spacing', NS)
            if sp is not None and sp.get(q('before')) and int(sp.get(q('before'))) > 60: sp.set(q('before'), '60')
            if sp is not None and sp.get(q('line')) == '297': sp.set(q('line'), '264')
            for tb in e.findall('w:pPr/w:tabs/w:tab', NS):
                if tb.get(q('pos')) == '492': tb.set(q('pos'), '660')
    # quotation column widths (all 6-column tables)
    widths = [450, 1400, 4363, 520, 1500, 1580]
    for tb in body.iter(q('tbl')):
        grid = tb.find('w:tblGrid', NS)
        if grid is not None and len(grid.findall('w:gridCol', NS)) == 6:
            for gc, w in zip(grid.findall('w:gridCol', NS), widths): gc.set(q('w'), str(w))
            for tr in tb.findall('w:tr', NS):
                cs = tr.findall('w:tc', NS)
                if len(cs) == 6:
                    for c, w in zip(cs, widths): c.find('w:tcPr/w:tcW', NS).set(q('w'), str(w))
                elif len(cs) == 1:
                    cs[0].find('w:tcPr/w:tcW', NS).set(q('w'), str(sum(widths)))
    # styles + numbering sizes
    for f in ('styles.xml', 'numbering.xml'):
        p = os.path.join(u, 'word', f); tr_ = etree.parse(p); r = tr_.getroot()
        if f == 'styles.xml':
            for s in r.findall('w:style', NS):
                if s.get(q('styleId')) in ('Normal', 'Heading1', 'BodyText', 'TableParagraph', 'ListParagraph'): setsz(s)
            setsz(r.find('w:docDefaults', NS))
        else: setsz(r)
        tr_.write(p, xml_declaration=True, encoding='UTF-8', standalone=True)
    # header: 10pt, widen, right-align, title
    hp = os.path.join(u, 'word/header1.xml'); x = open(hp, encoding='utf8').read()
    x = x.replace('w:val="15"', 'w:val="20"').replace('<wp:posOffset>5225034</wp:posOffset>', '<wp:posOffset>4482714</wp:posOffset>')
    x = x.replace('cx="1757680" cy="132715"', 'cx="2500000" cy="190000"')
    x = re.sub(r'<w:pPr><w:spacing w:before="16"/><w:ind w:left="20"/>', '<w:pPr><w:spacing w:before="16"/><w:ind w:left="20"/><w:jc w:val="right"/>', x)
    open(hp, 'w', encoding='utf8').write(x)
    title = (offer.get('title') or 'STEEL WORKING MACHINES').upper()
    hx = etree.parse(hp); hr = hx.getroot()
    for p in hr.iter(q('p')):
        if ''.join(p.itertext()).strip() == 'STEEL WORKING MACHINES OFFER': set_par_text(p, title + ' OFFER')
    hx.write(hp, xml_declaration=True, encoding='UTF-8', standalone=True)
    # footer: 8pt, boxes
    fp = os.path.join(u, 'word/footer1.xml'); fx = open(fp, encoding='utf8').read()
    fx = re.sub(r'(<w:sz(?:Cs)? w:val=")\d+(")', r'\g<1>16\2', fx)
    fx = fx.replace('<wp:posOffset>9748695</wp:posOffset>', '<wp:posOffset>9751743</wp:posOffset>').replace('<wp:posOffset>4770882</wp:posOffset>', '<wp:posOffset>4400000</wp:posOffset>')
    fx = fx.replace('cx="2352675" cy="411480"', 'cx="2895000" cy="520000"').replace('cx="2352675" cy="413384"', 'cx="2895000" cy="520000"')
    open(fp, 'w', encoding='utf8').write(fx)
    fx2 = etree.parse(fp)
    for r in fx2.getroot().iter(q('r')):
        rp = r.find('w:rPr', NS)
        if rp is None: rp = etree.Element(q('rPr')); r.insert(0, rp)
        if rp.find('w:sz', NS) is None:
            etree.SubElement(rp, q('sz')).set(q('val'), '16'); etree.SubElement(rp, q('szCs')).set(q('val'), '16')
    fx2.write(fp, xml_declaration=True, encoding='UTF-8', standalone=True)
    # bottom margin + page borders (sections after cover)
    sps = body.findall('.//w:sectPr', NS)
    for sp in sps[1:]:
        pm = sp.find('w:pgMar', NS)
        if pm is not None: pm.set(q('bottom'), '1500')
    for el in body.iter(q('pgBorders')):
        for side in el: side.set(q('color'), PAGE_BORDER)
    cover(b, offer, assets)


# ------------------------------------------------------------------ cover
def cover(b, offer, assets):
    u = b.u; body = b.body
    for src, name, rid in (('logo.jpg', 'cover_logo.jpeg', 'rId901'), ('mark.jpg', 'cover_mark.jpeg', 'rId902'), ('cover_bg.jpg', 'cover_bg.jpeg', 'rId903')):
        shutil.copy(os.path.join(assets, src), os.path.join(u, 'word/media', name))
        b.rels = b.rels.replace('</Relationships>', '<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/%s"/></Relationships>' % (rid, name))
    sizes = {'rId901': Image.open(os.path.join(assets, 'logo.jpg')).size}
    PW = 11910; ORG = MID; E = escape
    def R(t, sz, color, bold=False, sp=0):
        return '<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>%s<w:color w:val="%s"/>%s<w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (
            '<w:b/><w:bCs/>' if bold else '', color, '<w:spacing w:val="%d"/>' % sp if sp else '', sz, sz, E(t))
    def P(runs, jc=None, before=0, after=0, left=0, right=0, line=None, border=None):
        pp = '<w:pStyle w:val="TableParagraph"/>' + ('<w:pBdr>%s</w:pBdr>' % border if border else '') + '<w:spacing w:before="%d" w:after="%d"%s/>' % (before, after, ' w:line="%d" w:lineRule="auto"' % line if line else '') + '<w:ind w:left="%d" w:right="%d"/>' % (left, right) + ('<w:jc w:val="%s"/>' % jc if jc else '')
        return '<w:p><w:pPr>%s</w:pPr>%s</w:p>' % (pp, runs)
    NOB = '<w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/>'
    def TBL(grid, rows, indent=0):
        return ('<w:tbl><w:tblPr><w:tblW w:w="%d" w:type="dxa"/><w:tblInd w:w="%d" w:type="dxa"/><w:tblBorders>%s</w:tblBorders><w:tblLayout w:type="fixed"/>'
                '<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>%s</w:tblGrid>%s</w:tbl>') % (sum(grid), indent, NOB, ''.join('<w:gridCol w:w="%d"/>' % g for g in grid), ''.join(rows))
    def TR(cells, h): return '<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="%d" w:hRule="exact"/></w:trPr>%s</w:tr>' % (h, ''.join(cells))
    def TC(w, content, va='top', borders=''):
        return '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s<w:vAlign w:val="%s"/></w:tcPr>%s</w:tc>' % (w, '<w:tcBorders>%s</w:tcBorders>' % borders if borders else '', va, content)
    def logo_run():
        w, h = sizes['rId901']; cx = int(2.5 * 914400); cy = int(cx * h / w)
        return ('<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="%d" cy="%d"/><wp:docPr id="901" name="Cover logo" descr="Invotex Machinery"/>'
                '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>'
                '<pic:nvPicPr><pic:cNvPr id="901" name="c.jpg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId901"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
                '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>') % (cx, cy, cx, cy)
    cx, cy = 7562850, 10693400
    bgxml = ('<w:r><w:drawing><wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="0" behindDoc="1" locked="0" layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/>'
             '<wp:positionH relativeFrom="page"><wp:posOffset>0</wp:posOffset></wp:positionH><wp:positionV relativeFrom="page"><wp:posOffset>0</wp:posOffset></wp:positionV>'
             '<wp:extent cx="%d" cy="%d"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/><wp:docPr id="990" name="Cover artwork" descr="Machine collage"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
             '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="990" name="cover_bg.jpg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId903"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
             '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>') % (cx, cy, cx, cy)
    details = [('Offer No', offer.get('offer_no', '')), ('Customer', offer.get('company', '')), ('Location', offer.get('location', '')),
               ('Date', offer.get('date', '')), ('Validity', offer.get('validity', '')), ('Attention', offer.get('attention', ''))]
    rows = []
    for k, v in details:
        bd = '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="BFD1E3"/>'
        rows.append(TR([TC(2300, P(R(k.upper(), 16, ORG, True, 40)), 'center', bd), TC(5200, P(R(v, 26, NAVY, True), left=60), 'center', bd)], 620))
    det = TBL([2300, 5200], rows, indent=1133)
    row1 = TR([TC(PW, '<w:p><w:pPr><w:pStyle w:val="TableParagraph"/><w:spacing w:before="640" w:after="0"/><w:ind w:left="1133"/></w:pPr>' + bgxml + logo_run() + '</w:p>')], 7300)
    title = (offer.get('title') or 'STEEL WORKING MACHINES').upper()
    row2 = TR([TC(PW, P('', border='<w:bottom w:val="single" w:sz="48" w:space="1" w:color="%s"/>' % ORG, left=1133, right=9300, after=300, line=240, before=900)
                  + P(R('OFFER', 180, NAVY, True, 50), left=1133, after=40) + P(R(title, 38, NAVY, True, 30), left=1133, after=560) + det + P(''))], 9500)
    cover_xml = TBL([PW], [row1, row2])
    els = list(body); sect_par = els[[i for i, e in enumerate(els) if e.findall('.//w:sectPr', NS)][0]]
    idx = els.index(sect_par)
    for e in els[:idx]: body.remove(e)
    for k, e in enumerate(etree.fromstring('<w:root %s>%s</w:root>' % (NSDECL, cover_xml))): body.insert(k, e)
    pPr = sect_par.find('w:pPr', NS)
    for ch in list(pPr):
        if ch.tag != q('sectPr'): pPr.remove(ch)
    sp = etree.Element(q('spacing')); sp.set(q('before'), '0'); sp.set(q('after'), '0'); sp.set(q('line'), '20'); sp.set(q('lineRule'), 'exact'); pPr.insert(0, sp)
    for r in sect_par.findall('w:r', NS): sect_par.remove(r)
    pm = sect_par.find('.//w:pgMar', NS)
    for a in ('top', 'right', 'bottom', 'left', 'header', 'footer'): pm.set(q(a), '0')
