# -*- coding: utf-8 -*-
import json
from decimal import Decimal

from django import forms
from django.core.exceptions import ValidationError

from . import importer
from .models import NEW_TITLE_VALUE, SECTION_CHOICES, Machine, Offer, OfferTitle, SiteSettings
from .utils import DATE_FORMATS, normalize_lines

MAX_CATALOG_UPLOAD_MB = 80


class OfferForm(forms.ModelForm):
    date = forms.DateField(
        label='Offer date (dd-mm-yyyy)', input_formats=list(DATE_FORMATS),
        widget=forms.DateInput(format='%d-%m-%Y', attrs={'placeholder': 'dd-mm-yyyy'}),
        error_messages={'invalid': 'Date must look like 25-10-2026.'})
    title = forms.ChoiceField(label='Offer title (cover page)', required=False, choices=[])
    # shown when "+ Create new title" is chosen in the dropdown
    new_title = forms.CharField(label='New title', required=False, max_length=120,
                                widget=forms.TextInput(attrs={'placeholder': 'Type the new title, e.g. WOOD WORKING MACHINES'}))
    # The machine lines are edited in the browser and travel as JSON in this hidden field.
    lines_json = forms.CharField(required=False, widget=forms.HiddenInput)

    class Meta:
        model = Offer
        fields = ['company', 'attention', 'location', 'offer_no', 'date', 'validity_days', 'title',
                  'delivery_area', 'origin', 'discount_pct']
        error_messages = {'company': {'required': 'Enter the customer (company) name.'},
                          'offer_no': {'required': 'Enter an offer number (or press "Auto").'}}

    cleaned_lines = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        site = SiteSettings.load()
        current = self.instance.title if self.instance and self.instance.pk else ''
        self.fields['title'].choices = ([(t, t) for t in OfferTitle.choices(site.default_title, current)]
                                        + [(NEW_TITLE_VALUE, '+ Create new title...')])
        self.created_title = ''

    def clean_offer_no(self):
        v = self.cleaned_data['offer_no'].strip()
        if Offer.objects.filter(offer_no=v).exclude(pk=self.instance.pk).exists():
            raise ValidationError('An offer with this number already exists. Press "Auto" for a new number.')
        return v

    def clean_title(self):
        v = (self.cleaned_data.get('title') or '').strip()
        if v == NEW_TITLE_VALUE:
            return v                      # resolved in clean() together with the new_title box
        return v or SiteSettings.load().default_title

    def clean(self):
        data = super().clean()
        if data.get('title') == NEW_TITLE_VALUE:
            new = ' '.join((data.get('new_title') or '').split())
            if not new:
                self.add_error('new_title', 'Type the new title (or choose one from the list).')
            else:
                data['title'] = new
                self.created_title = new
        return data

    def ensure_new_title(self):
        """Add a title typed through "+ Create new title" to the dropdown list (call after the offer is saved)."""
        if not self.created_title:
            return None
        last = OfferTitle.objects.order_by('-sort_order').values_list('sort_order', flat=True).first() or 0
        obj, _ = OfferTitle.objects.get_or_create(name=self.created_title, defaults={'sort_order': last + 10})
        return obj

    def clean_discount_pct(self):
        return self.cleaned_data.get('discount_pct') or Decimal('0')

    def clean_lines_json(self):
        raw = self.cleaned_data.get('lines_json') or '[]'
        try:
            data = json.loads(raw)
        except ValueError:
            raise ValidationError('The machine list could not be read. Reload the page and try again.')
        known = set(Machine.objects.values_list('slug', flat=True))
        lines, errors = normalize_lines(data, known)
        if errors:
            raise ValidationError(errors)
        self.cleaned_lines = lines
        return raw


class MachineForm(forms.ModelForm):
    # Optional: a catalogue file whose pages are copied exactly as they are into the offer.
    catalog_file = forms.FileField(label='Catalogue file to copy exactly (PDF, Word or picture)', required=False)
    page_from = forms.IntegerField(label='From page', min_value=1, required=False)
    page_to = forms.IntegerField(label='to page', min_value=1, required=False)
    clear_pages = forms.BooleanField(label='Remove the stored catalogue pages', required=False)

    class Meta:
        model = Machine
        fields = ['section', 'category', 'model_no', 'title', 'tech_title', 'make', 'origin', 'image',
                  'image_width', 'image_max_h', 'lines', 'tech', 'use_catalog_pages']
        widgets = {
            'lines': forms.Textarea(attrs={'rows': 5}),
            'tech': forms.Textarea(attrs={'rows': 22, 'class': 'mono', 'spellcheck': 'false', 'wrap': 'off'}),
        }

    def clean_catalog_file(self):
        f = self.cleaned_data.get('catalog_file')
        if f:
            kind = importer.kind_of(f.name)
            if kind not in ('pdf', 'docx', 'image'):
                raise ValidationError('Use a PDF, a Word (.docx) file or a picture for the exact catalogue pages.')
            if f.size > MAX_CATALOG_UPLOAD_MB * 1024 * 1024:
                raise ValidationError('The file is larger than %d MB.' % MAX_CATALOG_UPLOAD_MB)
        return f

    def clean(self):
        data = super().clean()
        has_pages = bool(self.instance.pk and self.instance.pages.exists() and not data.get('clear_pages'))
        if data.get('use_catalog_pages') and not data.get('catalog_file') and not has_pages:
            self.add_error('use_catalog_pages', 'Choose the catalogue file below (or import a catalog) so there are pages to copy.')
        return data


class CatalogFileImportForm(forms.Form):
    """Import a supplier catalog (PDF / Word / picture / text) into one of the catalog sections."""
    file = forms.FileField(label='Catalog file (PDF, Word, picture or text)')
    section = forms.ChoiceField(label='Section', choices=SECTION_CHOICES)
    as_is = forms.BooleanField(label='Add the technical specification exactly as in the file (copy its pages into the offer)',
                               required=False)
    page_from = forms.IntegerField(label='From page', min_value=1, required=False)
    page_to = forms.IntegerField(label='to page', min_value=1, required=False)

    def clean_file(self):
        f = self.cleaned_data['file']
        kind = importer.kind_of(f.name)
        if kind == 'doc':
            raise ValidationError('Old .doc files cannot be read. Save the file as .docx or PDF and upload it again.')
        if not kind:
            raise ValidationError('This file type is not supported. Use PDF, Word (.docx), a picture (jpg, png ...) or a text file.')
        if f.size > MAX_CATALOG_UPLOAD_MB * 1024 * 1024:
            raise ValidationError('The file is larger than %d MB.' % MAX_CATALOG_UPLOAD_MB)
        return f


class SettingsForm(forms.ModelForm):
    class Meta:
        model = SiteSettings
        fields = ['lead_time', 'validity_days', 'delivery_area', 'price_basis', 'currency', 'offer_prefix',
                  'default_title']


class TitleForm(forms.ModelForm):
    sort_order = forms.IntegerField(label='Order', min_value=0, required=False)

    class Meta:
        model = OfferTitle
        fields = ['name', 'sort_order']

    def clean_sort_order(self):
        return self.cleaned_data.get('sort_order') or 0


class CatalogImportForm(forms.Form):
    file = forms.FileField(label='Catalog backup (.zip)')

    def clean_file(self):
        f = self.cleaned_data['file']
        if not f.name.lower().endswith('.zip'):
            raise ValidationError('Please choose a .zip catalog backup.')
        return f
