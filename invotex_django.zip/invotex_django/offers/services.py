# -*- coding: utf-8 -*-
"""Business logic that touches the database or the filesystem."""
import io
import json
import os
import tempfile
import zipfile

from django.conf import settings
from django.core.files.base import ContentFile
from django.db import transaction
from django.utils import timezone
from PIL import Image

from . import engine, importer, pdfgen
from .models import SECTION_LABELS, Machine, MachinePage, Offer, OfferCounter, OfferTitle, SiteSettings
from .utils import safe_filename, slugify_text, unique_slug

ALLOWED_IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}
MAX_IMAGE_BYTES = 20 * 1024 * 1024


DEFAULT_TITLES = ['STEEL WORKING MACHINES', 'SHEET METAL WORKING MACHINES', 'METAL CUTTING MACHINES', 'WORKSHOP MACHINES',
                  'WOOD WORKING MACHINES', 'ALUMINIUM MACHINES', 'STEEL MACHINES', 'SPECIAL MACHINES']

# the machines shipped with the program: everything is steel working except the compressor
DEFAULT_SECTIONS = {'compressor-inoair-15kw-vfd': 'special'}


def seed_default_titles():
    """Create the starting dropdown titles (and the settings default) if missing. Returns how many were added."""
    names = DEFAULT_TITLES + [SiteSettings.load().default_title]
    added = 0
    for i, name in enumerate(dict.fromkeys(n.strip() for n in names if n and n.strip())):
        _, created = OfferTitle.objects.get_or_create(name=name, defaults={'sort_order': i * 10})
        added += created
    return added


# ------------------------------------------------------------------ offer numbers
def _day_key(date=None):
    return (date or timezone.localdate()).strftime('%y%m%d')


def next_offer_no(site_settings, date=None):
    """PREFIX + yymmdd + -NN, skipping numbers that already exist."""
    key = _day_key(date)
    counter = OfferCounter.objects.filter(date_key=key).first()
    n = (counter.last_no if counter else 0) + 1
    while True:
        cand = '%s%s-%02d' % (site_settings.offer_prefix, key, n)
        if not Offer.objects.filter(offer_no=cand).exists():
            return cand
        n += 1


@transaction.atomic
def commit_offer_no(site_settings, offer_no, date=None):
    """Record the sequence number of a saved offer so today's next automatic number moves on.

    Only numbers in the automatic format (PREFIX + yymmdd + -NN for today) are recorded.
    """
    key = _day_key(date)
    stem = '%s%s-' % (site_settings.offer_prefix, key)
    if not offer_no.startswith(stem) or not offer_no[len(stem):].isdigit():
        return
    n = int(offer_no[len(stem):])
    counter, _ = OfferCounter.objects.select_for_update().get_or_create(date_key=key)
    if n > counter.last_no:
        counter.last_no = n
        counter.save()


# ------------------------------------------------------------------ Word offer
def generate_docx(offer):
    """Build the .docx for a saved Offer and return it as bytes. Raises engine.OfferError on bad input."""
    site = SiteSettings.load()
    ids = [ln['id'] for ln in offer.lines]
    machines = {m.slug: m.as_engine_dict() for m in Machine.objects.filter(slug__in=ids)}
    payload = offer.to_engine_offer(site)
    with tempfile.TemporaryDirectory(prefix='invotex_out_') as tmp:
        out = os.path.join(tmp, 'offer.docx')
        engine.generate_offer(payload, machines, str(settings.MEDIA_ROOT), str(settings.OFFER_ASSETS_DIR), out,
                              site.as_dict())
        with open(out, 'rb') as f:
            return f.read()


# ------------------------------------------------------------------ catalog import / export
def _valid_image(blob):
    try:
        Image.open(io.BytesIO(blob)).verify()
        return True
    except Exception:
        return False


def _s(d, key, maxlen):
    v = d.get(key, '')
    return ('' if v is None else str(v)).strip()[:maxlen] if key not in ('lines', 'tech') else ('' if v is None else str(v)).strip()


def _f(v, default, lo, hi):
    try:
        x = float(v)
        return x if lo <= x <= hi else default
    except (TypeError, ValueError):
        return default


def _jpeg_bytes(img, quality=88, max_w=None):
    """PIL image -> JPEG bytes (optionally limited in width)."""
    img = img.convert('RGB')
    if max_w and img.width > max_w:
        img = img.resize((max_w, int(img.height * max_w / img.width)), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, 'JPEG', quality=quality)
    return buf.getvalue()


def store_pages(machine, images):
    """Replace the catalogue pages of a machine by `images` (list of PIL images, in order)."""
    machine.pages.all().delete()                  # post_delete removes the files
    for i, im in enumerate(images):
        p = MachinePage(machine=machine, order=i)
        p.image.save('%s_p%02d.jpg' % (machine.slug, i + 1), ContentFile(_jpeg_bytes(im, 86, 1600)), save=False)
        p.save()
    return len(images)


@transaction.atomic
def import_machines(incoming, read_image, skip_existing=False, read_page=None, section_for=None):
    """Create Machine rows from dicts in the old catalog.json format.

    read_image(name) -> bytes or None.  Returns the number of machines added.
    Existing ids are kept: either skipped (skip_existing) or the newcomer gets a new id.
    The catalog section comes from the dict ('section'), else from section_for[id], else it is guessed from the name.
    """
    existing = set(Machine.objects.values_list('slug', flat=True))
    added = 0
    for d in incoming:
        if not isinstance(d, dict):
            continue
        slug = slugify_text(str(d.get('id') or '')) if d.get('id') else ''
        if not slug:
            slug = unique_slug(slugify_text('%s-%s' % (d.get('model', ''), d.get('title', '')))[:60], existing)
        orig_slug = slug
        if slug in existing:
            if skip_existing:
                continue
            slug = unique_slug(slug, existing)
        sec = str(d.get('section') or '') or (section_for or {}).get(orig_slug, '')
        if sec not in SECTION_LABELS:
            sec = importer.guess_section('%s %s %s' % (d.get('title', ''), d.get('category', ''), d.get('model', '')))
        m = Machine(
            slug=slug[:80], section=sec, category=_s(d, 'category', 250), model_no=_s(d, 'model', 120),
            title=_s(d, 'title', 250) or 'NEW MACHINE', tech_title=_s(d, 'tech_title', 300),
            make=_s(d, 'make', 200), origin=_s(d, 'origin', 100), lines=_s(d, 'lines', 0), tech=_s(d, 'tech', 0),
            image_width=_f(d.get('image_width'), 3.0, 0.5, 7.0), image_max_h=_f(d.get('image_max_h'), 2.3, 0.5, 9.0),
            use_catalog_pages=bool(d.get('use_catalog_pages')) and bool(d.get('pages')),
        )
        name = os.path.basename(str(d.get('image') or ''))
        if name and os.path.splitext(name)[1].lower() in ALLOWED_IMAGE_EXT:
            blob = read_image(name)
            if blob and _valid_image(blob):
                m.image.save(name, ContentFile(blob), save=False)
        m.save()
        if read_page and isinstance(d.get('pages'), list):
            for i, pname in enumerate(d['pages']):
                blob = read_page(os.path.basename(str(pname)))
                if blob and _valid_image(blob):
                    pg = MachinePage(machine=m, order=i)
                    pg.image.save('%s_p%02d.jpg' % (m.slug, i + 1), ContentFile(blob), save=False)
                    pg.save()
        existing.add(m.slug)
        added += 1
    return added


def import_catalog_zip(file_obj):
    """Import a backup zip (catalog.json + images/ + pages/) made by this app or by the old desktop program."""
    with zipfile.ZipFile(file_obj) as z:
        data = json.loads(z.read('catalog.json').decode('utf8'))
        names = {os.path.basename(n): n for n in z.namelist() if n.startswith('images/') and not n.endswith('/')}
        pnames = {os.path.basename(n): n for n in z.namelist() if n.startswith('pages/') and not n.endswith('/')}

        def reader(name):
            n = names.get(os.path.basename(name or ''))
            if not n or z.getinfo(n).file_size > MAX_IMAGE_BYTES:
                return None
            return z.read(n)

        def page_reader(name):
            n = pnames.get(os.path.basename(name or ''))
            if not n or z.getinfo(n).file_size > MAX_IMAGE_BYTES:
                return None
            return z.read(n)

        return import_machines(data.get('machines', []), reader, read_page=page_reader)


def load_default_catalog():
    """Seed the catalog with the 10 machines shipped with the original program (skips ones already present)."""
    base = settings.DEFAULT_CATALOG_DIR
    with open(os.path.join(base, 'catalog.json'), encoding='utf8') as f:
        machines = json.load(f).get('machines', [])

    def reader(name):
        p = os.path.join(base, 'images', os.path.basename(name))
        if os.path.exists(p):
            with open(p, 'rb') as fh:
                return fh.read()
        return None

    return import_machines(machines, reader, skip_existing=True, section_for=DEFAULT_SECTIONS)


def export_catalog_zip():
    """Backup zip in the same format the desktop program used (so both can import it); sections and catalogue pages are included."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        machines = []
        for m in Machine.objects.all():
            d = m.as_engine_dict()
            d.pop('catalog_pages', None)
            d['image'] = ''
            if m.image and os.path.exists(m.image.path):
                name = os.path.basename(m.image.name)
                z.write(m.image.path, 'images/' + name)
                d['image'] = name
            d['pages'] = []
            for i, pg in enumerate(m.pages.all()):
                if pg.image and os.path.exists(pg.image.path):
                    pname = '%s_p%02d.jpg' % (m.slug, i + 1)
                    z.write(pg.image.path, 'pages/' + pname)
                    d['pages'].append(pname)
            machines.append(d)
        z.writestr('catalog.json', json.dumps({'machines': machines}, ensure_ascii=False, indent=1))
    buf.seek(0)
    return buf


# ------------------------------------------------------------------ import ONE catalog file into a section
def _save_upload_to_temp(uploaded):
    ext = os.path.splitext(uploaded.name)[1].lower()
    fd, path = tempfile.mkstemp(prefix='invotex_up_', suffix=ext)
    with os.fdopen(fd, 'wb') as out:
        for chunk in uploaded.chunks():
            out.write(chunk)
    return path


def attach_catalog_pages(machine, uploaded, page_from=None, page_to=None):
    """Copy the pages of an uploaded PDF / Word file / picture exactly as they are into the machine. Returns the page count."""
    path = _save_upload_to_temp(uploaded)
    try:
        src = importer.read_file(path, uploaded.name)
        images = importer.catalogue_page_images(src, page_from, page_to)
        if not images:
            raise importer.ImportErrorMessage('No pages could be copied from this file.')
        return store_pages(machine, images)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def import_uploaded_catalog(uploaded, section, as_is=False, page_from=None, page_to=None):
    """Create a machine in `section` from a supplier catalog file.

    Returns (machine, notes) where notes is a list of readable remarks (what was found / what could not be done).
    Raises importer.ImportErrorMessage when the file cannot be used at all.
    """
    notes = []
    path = _save_upload_to_temp(uploaded)
    try:
        src = importer.read_file(path, uploaded.name)
        base_name = os.path.splitext(os.path.basename(uploaded.name))[0].replace('_', ' ').replace('-', ' ').strip()
        if src['kind'] == 'image':
            res = {'title': base_name.upper(), 'model': '', 'category': '', 'tech_title': '', 'make': '', 'origin': '',
                   'lines': '', 'tech': '', 'no_text_pages': [], 'stats': {}, 'removed': []}
            notes.append('A picture has no readable text, so only the machine picture was imported. Type the details in.')
        else:
            res = importer.analyze(src, page_from, page_to)
            if not res['tech']:
                notes.append('No readable text was found (scanned or picture-only file). Type the details in, or use the pages exactly as they are.')
            elif res['no_text_pages']:
                notes.append('Page(s) %s have almost no readable text (they are pictures).' % ', '.join(str(n) for n in res['no_text_pages'][:8]))
        m = Machine(
            section=section if section in SECTION_LABELS else importer.guess_section(res['title'] + ' ' + res['tech'][:500]),
            category=(res['category'] or '')[:250], model_no=(res['model'] or '')[:120],
            title=((res['title'] or base_name.upper()) or 'NEW MACHINE')[:250], tech_title=(res['tech_title'] or '')[:300],
            make=(res['make'] or '')[:200], origin=(res['origin'] or '')[:100], lines=res['lines'] or '', tech=res['tech'] or '')
        pics = importer.candidate_pictures(src, page_from, page_to)
        if pics:
            m.image.save('import_%s.jpg' % slugify_text(m.title)[:40], ContentFile(_jpeg_bytes(pics[0]['image'], 90, 1400)), save=False)
        else:
            notes.append('No picture was found in the file. Add the machine picture below.')
        with open(path, 'rb') as f:
            m.source_file.save(safe_filename(uploaded.name).replace(' ', '_') or 'catalog', ContentFile(f.read()), save=False)
        m.save()
        if as_is:
            try:
                images = importer.catalogue_page_images(src, page_from, page_to)
                store_pages(m, images)
                m.use_catalog_pages = True
                m.save(update_fields=['use_catalog_pages'])
                notes.append('%d catalogue page%s copied exactly as they are into the technical pages.' % (len(images), '' if len(images) == 1 else 's'))
            except importer.ImportErrorMessage as e:
                notes.append(str(e))
        if res['stats']:
            st = res['stats']
            notes.insert(0, 'Found %d specification rows, %d bullet points and %d table rows; removed %d lines (prices, contact details, repeated headers).'
                         % (st.get('specs', 0), st.get('bullets', 0), st.get('tables', 0), st.get('removed', 0)))
        return m, notes
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


# ------------------------------------------------------------------ PDF catalogs
def machine_pdf_bytes(machine):
    return pdfgen.machine_pdf(machine.as_engine_dict(), str(settings.OFFER_ASSETS_DIR), machine.section_label)


def section_pdf_bytes(section):
    """section = one of the section keys, or 'all'."""
    if section == 'all':
        qs = Machine.objects.all()
        label = 'All machines'
    else:
        qs = Machine.objects.filter(section=section)
        label = SECTION_LABELS.get(section, section)
    machines = [m.as_engine_dict() for m in qs]
    return pdfgen.section_pdf(machines, str(settings.OFFER_ASSETS_DIR), label), label


def pdf_filename(*parts):
    name = '_'.join(safe_filename(p).replace(' ', '_') for p in parts if p).strip('_')
    return (name[:90] or 'catalog') + '.pdf'
