from django.contrib import admin

from .models import Machine, MachinePage, Offer, OfferCounter, OfferTitle, SiteSettings


class MachinePageInline(admin.TabularInline):
    model = MachinePage
    extra = 0


@admin.register(Machine)
class MachineAdmin(admin.ModelAdmin):
    list_display = ('model_no', 'title', 'section', 'origin', 'use_catalog_pages', 'slug')
    list_filter = ('section', 'use_catalog_pages')
    search_fields = ('model_no', 'title', 'category')
    inlines = [MachinePageInline]


@admin.register(Offer)
class OfferAdmin(admin.ModelAdmin):
    list_display = ('offer_no', 'company', 'date', 'created_at')
    search_fields = ('offer_no', 'company')


@admin.register(OfferTitle)
class OfferTitleAdmin(admin.ModelAdmin):
    list_display = ('name', 'sort_order')
    list_editable = ('sort_order',)


admin.site.register(SiteSettings)
admin.site.register(OfferCounter)
