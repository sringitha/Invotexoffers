(function () {
  'use strict';
  var catalog = JSON.parse(document.getElementById('catalog-data').textContent);
  var cfg = JSON.parse(document.getElementById('editor-config').textContent);
  var byId = {};
  catalog.forEach(function (m) { byId[m.slug] = m; });

  var form = document.getElementById('offer-form');
  var hidden = document.getElementById('id_lines_json');
  var body = document.getElementById('lines-body');
  var pickList = document.getElementById('pick-list');
  var search = document.getElementById('pick-search');
  var secSel = document.getElementById('pick-section');
  var totalEl = document.getElementById('total');
  var lines = [];
  try { lines = JSON.parse(hidden.value || '[]'); } catch (e) { lines = []; }
  if (!Array.isArray(lines)) lines = [];

  function sync() { hidden.value = JSON.stringify(lines); updateTotal(); }
  function num(s) { var x = parseFloat(String(s).replace(/,/g, '')); return isNaN(x) ? null : x; }
  function money(x) { return x.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}); }

  function updateTotal() {
    var sum = 0, all = lines.length > 0;
    lines.forEach(function (l) {
      var p = num(l.unit_price);
      if (p === null || p === 0) { all = false; return; }
      sum += p * (parseInt(l.qty, 10) || 1);
    });
    var d = num(document.getElementById('id_discount_pct').value) || 0;
    if (!all) { totalEl.textContent = ''; return; }
    totalEl.textContent = d > 0
      ? 'Total ' + money(sum) + ' ' + cfg.currency + ' - discount ' + d + '% = ' + money(sum - sum * d / 100) + ' ' + cfg.currency
      : 'Total ' + money(sum) + ' ' + cfg.currency;
  }

  function cell(tr, child) { var td = document.createElement('td'); if (child) td.appendChild(child); tr.appendChild(td); return td; }
  function input(cls, value, onInput, type) {
    var i = document.createElement('input');
    i.type = type || 'text'; i.className = cls; i.value = value == null ? '' : value;
    i.addEventListener('input', function () { onInput(i.value); sync(); });
    return i;
  }
  function button(label, title, fn) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'btn small'; b.textContent = label; b.title = title;
    b.addEventListener('click', fn); return b;
  }

  function render() {
    body.textContent = '';
    if (!lines.length) {
      var tr0 = document.createElement('tr'), td0 = document.createElement('td');
      td0.colSpan = 6; td0.className = 'empty'; td0.textContent = 'No machines yet - click one in the catalog list above.';
      tr0.appendChild(td0); body.appendChild(tr0);
    }
    lines.forEach(function (ln, i) {
      var m = byId[ln.id] || {model: '?', title: '(missing from catalog)'};
      var tr = document.createElement('tr');
      cell(tr).textContent = i + 1;
      var t = cell(tr); var b = document.createElement('b'); b.textContent = m.model || ''; t.appendChild(b);
      t.appendChild(document.createElement('br')); t.appendChild(document.createTextNode(m.title || ''));
      cell(tr, input('qty', ln.qty, function (v) { ln.qty = v; }, 'number'));
      cell(tr, input('price', ln.unit_price, function (v) { ln.unit_price = v; }));
      cell(tr, input('lead', ln.lead_time, function (v) { ln.lead_time = v; }));
      var mv = document.createElement('div'); mv.className = 'mv';
      mv.appendChild(button('\u2191', 'Move up', function () { move(i, -1); }));
      mv.appendChild(button('\u2193', 'Move down', function () { move(i, 1); }));
      mv.appendChild(button('\u00d7', 'Remove', function () { lines.splice(i, 1); render(); sync(); }));
      cell(tr, mv);
      body.appendChild(tr);
    });
    updateTotal();
  }

  function move(i, d) {
    var j = i + d;
    if (j < 0 || j >= lines.length) return;
    var t = lines[i]; lines[i] = lines[j]; lines[j] = t; render(); sync();
  }

  function fillPick() {
    var key = search.value.toLowerCase().trim();
    pickList.textContent = '';
    var sec = secSel ? secSel.value : '';
    catalog.forEach(function (m) {
      var hay = ((m.model || '') + ' ' + (m.title || '') + ' ' + (m.category || '')).toLowerCase();
      if (key && hay.indexOf(key) === -1) return;
      if (sec && m.section !== sec) return;
      var li = document.createElement('li'), b = document.createElement('b');
      b.textContent = m.model || ''; li.appendChild(b); li.appendChild(document.createTextNode(m.title || ''));
      li.title = 'Click to add';
      li.addEventListener('click', function () {
        lines.push({id: m.slug, qty: 1, unit_price: '', lead_time: cfg.leadTime || ''});
        render(); sync();
      });
      pickList.appendChild(li);
    });
    if (!pickList.children.length) {
      var li2 = document.createElement('li'); li2.textContent = 'No machines found.'; pickList.appendChild(li2);
    }
  }

  // ---- validity label
  function parseDate(s) {
    var m = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(s.trim());
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function updateValid() {
    var d = parseDate(document.getElementById('id_date').value);
    var days = parseInt(document.getElementById('id_validity_days').value, 10);
    var el = document.getElementById('valid-until');
    if (!d || isNaN(days)) { el.textContent = ''; return; }
    d.setDate(d.getDate() + days);
    el.textContent = 'Offer valid until: ' + pad(d.getDate()) + '-' + pad(d.getMonth() + 1) + '-' + d.getFullYear();
  }

  document.getElementById('auto-no').addEventListener('click', function () {
    fetch(cfg.autoUrl, {credentials: 'same-origin'}).then(function (r) { return r.json(); })
      .then(function (d) { document.getElementById('id_offer_no').value = d.offer_no; });
  });
  ['id_date', 'id_validity_days'].forEach(function (id) { document.getElementById(id).addEventListener('input', updateValid); });
  document.getElementById('id_discount_pct').addEventListener('input', updateTotal);
  search.addEventListener('input', fillPick);
  if (secSel) secSel.addEventListener('change', fillPick);
  form.addEventListener('submit', sync);

  // ---- offer title: "+ Create new title..." shows a box for the new name
  var titleSel = document.getElementById('id_title'), newBox = document.getElementById('new-title-box');
  function toggleNewTitle() {
    if (!titleSel || !newBox) return;
    var on = titleSel.value === '__new__';
    newBox.style.display = on ? '' : 'none';
    if (on) { var i = document.getElementById('id_new_title'); if (i && !i.value) i.focus(); }
  }
  if (titleSel) titleSel.addEventListener('change', toggleNewTitle);

  fillPick(); render(); updateValid(); sync(); toggleNewTitle();
})();
