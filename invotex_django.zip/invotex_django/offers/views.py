# -*- coding: utf-8 -*-
import io
import json
import os
import zipfile

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.db.models import Q
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from . import importer, services
from .engine import OfferError
from .forms import CatalogFileImportForm, CatalogImportForm, MachineForm, OfferForm, SettingsForm, TitleForm
from .models import SECTION_CHOICES, SECTION_LABELS, Machine, Offer, OfferTitle, SiteSettings

DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'


# ------------------------------------------------------------------ offers
@login_required
def offer_list(request):
    q = request.GET.get('q', '').strip()
    offers = Offer.objects.all()
    if q:
        offers = offers.filter(Q(company__icontains=q) | Q(offer_no__icontains=q) | Q(location__icontains=q))
    return render(request, 'offers/offer_list.html', {'offers': offers[:300], 'q': q, 'active': 'offers'})


@login_required
def offer_edit(request, pk=None):
    site = SiteSettings.load()
    offer = get_object_or_404(Offer, pk=pk) if pk else None

    if request.method == 'POST':
        form = OfferForm(request.POST, instance=offer)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.lines = form.cleaned_lines
            is_new = obj.pk is None
            obj.save()
            if form.ensure_new_title():
                messages.success(request, 'New title "%s" added to the title list.' % form.created_title)
            if is_new:
                services.commit_offer_no(site, obj.offer_no)
            if request.POST.get('action') == 'generate':
                return redirect(reverse('offers:edit', args=[obj.pk]) + '?dl=1')
            messages.success(request, 'Offer saved.')
            return redirect('offers:edit', pk=obj.pk)
        messages.error(request, 'Please fix the problems marked below.')
    elif offer:
        form = OfferForm(instance=offer, initial={'lines_json': json.dumps(offer.lines)})
    else:
        today = timezone.localdate()
        form = OfferForm(initial={
            'offer_no': services.next_offer_no(site), 'date': today, 'validity_days': site.validity_days,
            'title': site.default_title, 'delivery_area': site.delivery_area, 'lines_json': '[]',
        })

    catalog = [{'slug': m.slug, 'model': m.model_no, 'title': m.title, 'category': m.category, 'section': m.section}
               for m in Machine.objects.all()]
    ctx = {
        'form': form, 'offer': offer, 'active': 'offers', 'catalog_json': catalog, 'sections': SECTION_CHOICES,
        'editor_config': {'leadTime': site.lead_time, 'autoUrl': reverse('offers:next_number'),
                          'currency': site.currency},
        'auto_download_url': reverse('offers:download', args=[offer.pk]) if (offer and request.GET.get('dl')) else '',
    }
    return render(request, 'offers/offer_form.html', ctx)


@login_required
@require_GET
def offer_next_number(request):
    return JsonResponse({'offer_no': services.next_offer_no(SiteSettings.load())})


@login_required
def offer_download(request, pk):
    offer = get_object_or_404(Offer, pk=pk)
    try:
        data = services.generate_docx(offer)
    except OfferError as e:
        messages.error(request, str(e))
        return redirect('offers:edit', pk=offer.pk)
    except Exception as e:  # keep the user on the page with a readable message
        messages.error(request, 'Could not create the offer: %s' % e)
        return redirect('offers:edit', pk=offer.pk)
    return FileResponse(io.BytesIO(data), as_attachment=True, filename=offer.download_name(), content_type=DOCX_MIME)


@login_required
@require_POST
def offer_duplicate(request, pk):
    src = get_object_or_404(Offer, pk=pk)
    site = SiteSettings.load()
    dup = Offer(
        company=src.company, attention=src.attention, location=src.location,
        offer_no=services.next_offer_no(site), date=timezone.localdate(), validity_days=src.validity_days,
        title=src.title, delivery_area=src.delivery_area, origin=src.origin, discount_pct=src.discount_pct,
        lines=src.lines)
    dup.save()
    services.commit_offer_no(site, dup.offer_no)
    messages.success(request, 'Copy created with number %s.' % dup.offer_no)
    return redirect('offers:edit', pk=dup.pk)


@login_required
def offer_delete(request, pk):
    offer = get_object_or_404(Offer, pk=pk)
    if request.method == 'POST':
        offer.delete()
        messages.success(request, 'Offer %s deleted.' % offer.offer_no)
        return redirect('offers:list')
    return render(request, 'offers/confirm_delete.html', {
        'what': 'offer %s (%s)' % (offer.offer_no, offer.company), 'cancel_url': reverse('offers:edit', args=[pk]),
        'active': 'offers'})


# ------------------------------------------------------------------ catalog
@login_required
def machine_list(request):
    """The machine catalog, one tab per section (Aluminium, Steel, Wood working, Special) plus an 'All' view."""
    q = request.GET.get('q', '').strip()
    current = request.GET.get('section', '').strip()
    if current not in SECTION_LABELS:
        current = ''
    counts = {k: 0 for k, _ in SECTION_CHOICES}
    for sec in Machine.objects.values_list('section', flat=True):
        counts[sec] = counts.get(sec, 0) + 1
    machines = Machine.objects.all()
    if current:
        machines = machines.filter(section=current)
    if q:
        machines = machines.filter(Q(model_no__icontains=q) | Q(title__icontains=q) | Q(category__icontains=q))
    sections = [{'key': k, 'label': label, 'count': counts.get(k, 0)} for k, label in SECTION_CHOICES]
    import_form = CatalogFileImportForm(initial={'section': current or 'steel'})
    return render(request, 'offers/machine_list.html', {
        'machines': machines.prefetch_related('pages'), 'q': q, 'active': 'catalog', 'sections': sections, 'current': current,
        'current_label': SECTION_LABELS.get(current, ''), 'total': sum(counts.values()), 'import_form': import_form})


def _machine_form_view(request, machine):
    if request.method == 'POST':
        form = MachineForm(request.POST, request.FILES, instance=machine)
        if form.is_valid():
            m = form.save()
            cd = form.cleaned_data
            if cd.get('clear_pages') and not cd.get('catalog_file'):
                services.store_pages(m, [])
            f = cd.get('catalog_file')
            if f:
                try:
                    n = services.attach_catalog_pages(m, f, cd.get('page_from'), cd.get('page_to'))
                    messages.success(request, '%d catalogue page%s copied exactly as they are.' % (n, '' if n == 1 else 's'))
                except importer.ImportErrorMessage as e:
                    messages.error(request, str(e))
                except Exception as e:
                    messages.error(request, 'The catalogue pages could not be copied: %s' % e)
            if m.use_catalog_pages and not m.pages.exists():
                m.use_catalog_pages = False
                m.save(update_fields=['use_catalog_pages'])
                messages.error(request, 'No catalogue pages are stored, so "use the pages exactly as uploaded" was switched off.')
            messages.success(request, 'Machine saved.')
            return redirect('offers:machine_edit', pk=m.pk)
        messages.error(request, 'Please fix the problems marked below.')
    else:
        initial = None
        if not machine:
            sec = request.GET.get('section', '')
            initial = {'image_width': 3.0, 'image_max_h': 2.3, 'title': 'NEW MACHINE', 'section': sec if sec in SECTION_LABELS else 'steel'}
        form = MachineForm(instance=machine, initial=initial)
    return render(request, 'offers/machine_form.html', {'form': form, 'machine': machine, 'active': 'catalog',
                                                         'pages': list(machine.pages.all()) if machine else []})


@login_required
def machine_create(request):
    return _machine_form_view(request, None)


@login_required
def machine_edit(request, pk):
    return _machine_form_view(request, get_object_or_404(Machine, pk=pk))


@login_required
@require_POST
def machine_duplicate(request, pk):
    src = get_object_or_404(Machine, pk=pk)
    dup = Machine(section=src.section, category=src.category, model_no=('%s (copy)' % src.model_no).strip()[:120], title=src.title,
                  tech_title=src.tech_title, make=src.make, origin=src.origin, image_width=src.image_width,
                  image_max_h=src.image_max_h, lines=src.lines, tech=src.tech, use_catalog_pages=src.use_catalog_pages)
    if src.image and os.path.exists(src.image.path):
        with open(src.image.path, 'rb') as f:
            dup.image.save(os.path.basename(src.image.name), ContentFile(f.read()), save=False)
    dup.save()
    for i, pg in enumerate(src.pages.all()):
        if pg.image and os.path.exists(pg.image.path):
            with open(pg.image.path, 'rb') as f:
                np_ = services.MachinePage(machine=dup, order=i)
                np_.image.save(os.path.basename(pg.image.name), ContentFile(f.read()), save=False)
                np_.save()
    messages.success(request, 'Machine duplicated. Edit the copy below.')
    return redirect('offers:machine_edit', pk=dup.pk)


@login_required
def machine_delete(request, pk):
    machine = get_object_or_404(Machine, pk=pk)
    used = [o.offer_no for o in Offer.objects.all() if any(l.get('id') == machine.slug for l in o.lines)]
    if request.method == 'POST':
        machine.delete()
        messages.success(request, 'Machine deleted.')
        return redirect('offers:machine_list')
    warn = ('Used in saved offers: %s. Those offers cannot be generated until the machine is replaced.' % ', '.join(used)) if used else ''
    return render(request, 'offers/confirm_delete.html', {
        'what': 'machine "%s"' % machine, 'cancel_url': reverse('offers:machine_edit', args=[pk]),
        'warning': warn, 'active': 'catalog'})


@login_required
def catalog_export(request):
    buf = services.export_catalog_zip()
    return FileResponse(buf, as_attachment=True, filename='invotex_catalog_backup.zip', content_type='application/zip')


@login_required
def catalog_import(request):
    if request.method == 'POST':
        form = CatalogImportForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                n = services.import_catalog_zip(form.cleaned_data['file'])
            except (zipfile.BadZipFile, KeyError, ValueError) as e:
                messages.error(request, 'Could not import that file (is it a catalog backup?): %s' % e)
            else:
                messages.success(request, '%d machine(s) imported.' % n)
                return redirect('offers:machine_list')
    else:
        form = CatalogImportForm()
    return render(request, 'offers/catalog_import.html', {'form': form, 'active': 'catalog'})


@login_required
@require_POST
def catalog_import_file(request):
    """Import a supplier catalog (PDF / Word / picture / text) as a new machine in the chosen section."""
    form = CatalogFileImportForm(request.POST, request.FILES)
    section = request.POST.get('section', '')
    back = reverse('offers:machine_list') + ('?section=%s' % section if section in SECTION_LABELS else '')
    if not form.is_valid():
        for errs in form.errors.values():
            for e in errs:
                messages.error(request, e)
        return redirect(back)
    cd = form.cleaned_data
    try:
        m, notes = services.import_uploaded_catalog(cd['file'], cd['section'], cd['as_is'], cd.get('page_from'), cd.get('page_to'))
    except importer.ImportErrorMessage as e:
        messages.error(request, str(e))
        return redirect(back)
    except Exception as e:  # a damaged or unusual file: tell the user instead of showing a server error
        messages.error(request, 'This file could not be imported: %s' % e)
        return redirect(back)
    messages.success(request, 'Catalog imported as "%s" in %s. Please check the details below and press Save.' % (m.title, m.section_label))
    for n in notes:
        messages.info(request, n)
    return redirect('offers:machine_edit', pk=m.pk)


@login_required
def machine_pdf(request, pk):
    """PDF of one catalog entry (its data sheet, or the uploaded catalogue pages when those are used as they are)."""
    m = get_object_or_404(Machine, pk=pk)
    data = services.machine_pdf_bytes(m)
    return FileResponse(io.BytesIO(data), as_attachment=True, filename=services.pdf_filename(m.model_no, m.title),
                        content_type='application/pdf')


@login_required
def section_pdf(request, section):
    """PDF catalog of a whole section (cover, contents and every machine). section = a section key or 'all'."""
    if section != 'all' and section not in SECTION_LABELS:
        raise Http404('Unknown catalog section.')
    data, label = services.section_pdf_bytes(section)
    return FileResponse(io.BytesIO(data), as_attachment=True, filename=services.pdf_filename(label, 'catalog'),
                        content_type='application/pdf')


# ------------------------------------------------------------------ settings / help
@login_required
def settings_view(request):
    site = SiteSettings.load()
    if request.method == 'POST':
        form = SettingsForm(request.POST, instance=site)
        if form.is_valid():
            form.save()
            messages.success(request, 'Settings saved.')
            return redirect('offers:settings')
    else:
        form = SettingsForm(instance=site)
    return render(request, 'offers/settings.html', {'form': form, 'active': 'settings'})


@login_required
def titles_view(request):
    """Manage the choices of the Title dropdown (stored in the OfferTitle table)."""
    if request.method == 'POST':
        form = TitleForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Title added.')
            return redirect('offers:titles')
    else:
        form = TitleForm()
    return render(request, 'offers/titles.html', {
        'form': form, 'titles': OfferTitle.objects.all(), 'default_title': SiteSettings.load().default_title,
        'active': 'titles'})


@login_required
@require_POST
def title_edit(request, pk):
    form = TitleForm(request.POST, instance=get_object_or_404(OfferTitle, pk=pk))
    if form.is_valid():
        form.save()
        messages.success(request, 'Title saved.')
    else:
        messages.error(request, ' '.join(e for errs in form.errors.values() for e in errs))
    return redirect('offers:titles')


@login_required
@require_POST
def title_delete(request, pk):
    t = get_object_or_404(OfferTitle, pk=pk)
    t.delete()
    messages.success(request, 'Title removed from the list. Saved offers keep the title they already have.')
    return redirect('offers:titles')


@login_required
def help_view(request):
    return render(request, 'offers/help.html', {'active': 'help'})
