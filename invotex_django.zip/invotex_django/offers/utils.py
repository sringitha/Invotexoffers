# -*- coding: utf-8 -*-
"""Pure-python helpers (no Django imports): dates, prices, line validation, slugs."""
import datetime
import re
from decimal import Decimal, InvalidOperation

DATE_FORMATS = ('%d-%m-%Y', '%d/%m/%Y', '%Y-%m-%d')


def parse_date(s):
    for fmt in DATE_FORMATS:
        try:
            return datetime.datetime.strptime(str(s).strip(), fmt).date()
        except Exception:
            pass
    return None


def fmt_date(d):
    return d.strftime('%d-%m-%Y')


def to_float(s):
    """'1,250.50' -> 1250.5 ; '' / None -> None ; garbage -> ValueError."""
    if s is None:
        return None
    s = str(s).replace(',', '').strip()
    if not s:
        return None
    return float(s)


def slugify_text(text):
    t = re.sub(r'[^a-z0-9]+', '-', (text or '').lower()).strip('-')
    return t or 'machine'


def unique_slug(base, existing):
    """base, base-2, base-3 ... first one not in `existing`."""
    i, cand = 2, base
    while cand in existing:
        cand = '%s-%d' % (base, i)
        i += 1
    return cand


def build_title_choices(db_titles, default='', current=''):
    """Ordered, de-duplicated list of dropdown titles.

    `db_titles` come from the database. The default title and the title already stored on the
    offer being edited are always included, so an old offer never loses its title.
    """
    out = []
    for t in list(db_titles) + [default, current]:
        t = (t or '').strip()
        if t and t not in out:
            out.append(t)
    return out


def safe_filename(text):
    return re.sub(r'[^A-Za-z0-9._ -]+', '_', text or '').strip()


def clean_price(value):
    """Return '' (blank price) or a normalised non-negative number string; raise ValueError otherwise."""
    s = str(value if value is not None else '').replace(',', '').strip()
    if not s:
        return ''
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise ValueError('not a number')
    if not d.is_finite() or d < 0:
        raise ValueError('not a valid price')
    return format(d, 'f')


def normalize_lines(raw, known_ids):
    """Validate the machine lines posted by the offer editor.

    Returns (lines, errors). Each line is {'id', 'qty', 'unit_price' (str, '' = blank), 'lead_time'}.
    """
    errors = []

    def err(msg):
        if msg not in errors:
            errors.append(msg)

    if not isinstance(raw, list) or not raw:
        return [], ['Add at least one machine.']
    out = []
    for ln in raw:
        if not isinstance(ln, dict):
            err('The machine list is invalid. Reload the page and try again.')
            continue
        mid = str(ln.get('id', ''))
        if mid not in known_ids:
            err('A selected machine no longer exists in the catalog.')
            continue
        raw_q = str(ln.get('qty', '')).strip()
        try:
            qty = int(float(raw_q)) if raw_q else 1
            if qty < 1:
                raise ValueError
        except ValueError:
            err('Quantity must be a whole number (1 or more).')
            continue
        try:
            price = clean_price(ln.get('unit_price'))
        except ValueError:
            err('Unit price must be a number.')
            continue
        out.append({'id': mid, 'qty': qty, 'unit_price': price, 'lead_time': str(ln.get('lead_time', ''))[:200]})
    if errors:
        return [], errors
    return out, []
