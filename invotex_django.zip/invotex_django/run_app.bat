@echo off
REM First run: installs packages, creates the database, loads the 10 default machines and asks you
REM to create the first user. Every run starts the site at http://127.0.0.1:8000
cd /d "%~dp0"
py -m pip install --quiet -r requirements.txt
if errorlevel 1 goto fail
py manage.py makemigrations offers
py manage.py migrate
py manage.py load_default_catalog
if not exist data\.user_created (
  echo.
  echo Create your login now:
  py manage.py createsuperuser
  if not errorlevel 1 echo done> data\.user_created
)
start "" http://127.0.0.1:8000
py manage.py runserver 127.0.0.1:8000
goto :eof
:fail
echo Could not install packages. Check your internet connection / Python installation.
pause
