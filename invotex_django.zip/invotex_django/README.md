# Invotex Offer Maker - Django version

Web version of the Invotex Offer Maker desktop program. You enter customer details, pick machines from the
catalog, set quantity / price / lead time, and the site creates the Word offer (cover page, quotation table with
totals, one technical page per machine, key offer details, conditions of supply, general conditions).

## Quick start

Needs Python 3.10+.

    # Windows: double-click run_app.bat      Linux/macOS: ./run_app.sh

or manually:

    pip install -r requirements.txt
    python manage.py makemigrations offers     # first time only
    python manage.py migrate
    python manage.py load_default_catalog      # the 10 machines from the desktop version
    python manage.py createsuperuser           # your login
    python manage.py runserver

Open http://127.0.0.1:8000 and log in.

## New in this version

1. **Offer title - create new.** The Title dropdown ends with *+ Create new title...*. Choose it, type the new title and save: it is
   used on the offer and added to the title list (Titles page) for next time.
2. **Four catalog sections.** The Machine catalog page has tabs: *Aluminium machines*, *Steel machines*, *Wood working machines*,
   *Special machines* (and *All*). Every machine belongs to one section (field *Catalog section*). The offer editor can filter its
   machine picker by section.
3. **Import a catalog file in every section.** Each section has an *Import a catalog* box: upload a PDF, Word (.docx), picture
   (jpg, png ...) or text file. The program reads it (`offers/importer.py`) and creates a draft machine in that section - model,
   name, category, make/country, quotation description lines (working area / length / width / thickness first), technical page
   text and a picture. Prices, payment terms, warranty text, contact details and repeated headers are left out. Check the draft and
   press Save. Scanned (picture-only) files cannot be read as text.
4. **Technical specification exactly as uploaded.** Tick *Add the technical specification exactly as uploaded* in the import box or in
   the machine form. The original pages (PDF pages, Word pages or the picture; up to 12) are stored as pictures and copied unchanged
   into the technical pages of the Word offer, under the normal machine heading with brand and country of origin. Untick it to go
   back to the technical page text. Copying a **Word** file page for page needs LibreOffice installed on the server
   (`soffice`); without it, save the file as PDF first.
5. **PDF downloads.** Every machine has a *PDF* button (its data sheet - or the uploaded pages when they are used as they are).
   Every section has *Download ... catalog (PDF)* (cover page, contents, all machines) and the *All* tab downloads the full catalog.
   The PDFs are made with ReportLab (`offers/pdfgen.py`).

### Upgrading an existing installation

    pip install -r requirements.txt            # new packages: pdfplumber, pypdfium2, python-docx, reportlab
    python manage.py makemigrations offers
    python manage.py migrate
    python manage.py assign_sections --dry-run # optional: sorts old machines into sections by their name (drop --dry-run to apply)

Machines that existed before get the section *Steel machines* until you change them (or run `assign_sections`).
`python manage.py load_default_catalog` puts the 10 starting machines in their sections (the compressor goes to *Special machines*).
Catalog backups (zip) now also contain the sections and the stored catalogue pages; old backups still import.

## What maps to what

| Desktop version            | Django version                                           |
|----------------------------|----------------------------------------------------------|
| `app.py` (Tkinter windows) | `offers/views.py`, `offers/templates/`, `static/offers/offer_editor.js` |
| `offer_engine.py`          | `offers/engine.py` (same logic; output is byte-identical) |
| `offer_state.py`           | `Offer` model + `OfferForm` + `utils.normalize_lines`    |
| `catalog_store.py`         | `Machine`, `SiteSettings`, `OfferCounter`, `Offer` models + `services.py` |
| `data/catalog.json`, `images/` | `Machine` table + uploaded pictures in `data/media/machines/` |
| `data/settings.json`       | Settings page (`SiteSettings`)                           |
| `data/offers/*.json`       | Offers list (`Offer` table)                              |
| `assets/`, `default_catalog/` | `offers/assets/`, `offers/default_catalog/`           |
| PyInstaller `.exe`         | not needed - run as a website                            |
| (new) catalog reader       | `offers/importer.py` (pdfplumber / python-docx / Pillow)  |
| (new) PDF catalogs         | `offers/pdfgen.py` (ReportLab)                           |

## Offer title dropdown

The Title field on the offer form is a dropdown filled from the database (table `OfferTitle`). Add, rename,
reorder and delete the choices on the **Titles** page (or in `/admin/`). The starting titles are created by
`python manage.py load_default_catalog`. After pulling this change run `python manage.py makemigrations offers && python manage.py migrate`.

## Moving your real catalog over

In the old program: Machine catalog -> Export catalog (zip).
In the site: Machine catalog -> Import backup. The zip format is the same both ways.

## Notes

* Everything (database + pictures) lives in `data/`. Back that folder up, or use Export backup for the catalog.
* The fixed pages come from `offers/assets/template.docx` - edit it in Word, keep its page structure.
* Extra find/replace rules for the template text can be added in the admin (`/admin/` -> Settings -> replacements,
  e.g. `[["old text", "new text"]]`).
* Users are managed in `/admin/` (add staff users for colleagues). Every page requires login.

## Deploying on a server

    export DJANGO_DEBUG=0
    export DJANGO_SECRET_KEY='a-long-random-string'
    export DJANGO_ALLOWED_HOSTS=offers.example.com
    export DJANGO_CSRF_TRUSTED=https://offers.example.com
    pip install gunicorn
    python manage.py collectstatic --noinput
    gunicorn invotex_site.wsgi

Serve `/static/` (from `staticfiles/`) with nginx or add WhiteNoise. Uploaded pictures are served by Django
to logged-in users only. For several users at once, switch `DATABASES` to PostgreSQL.

## Tests

    python manage.py test offers
