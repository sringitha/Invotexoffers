#!/usr/bin/env bash
# First run: installs packages, creates the database, loads the 10 default machines and asks you
# to create the first user. Every run starts the site at http://127.0.0.1:8000
set -e
cd "$(dirname "$0")"
python3 -m pip install -q -r requirements.txt
python3 manage.py makemigrations offers
python3 manage.py migrate
python3 manage.py load_default_catalog
if [ ! -f data/.user_created ]; then
  echo; echo "Create your login now:"
  python3 manage.py createsuperuser && touch data/.user_created
fi
python3 manage.py runserver 127.0.0.1:8000
